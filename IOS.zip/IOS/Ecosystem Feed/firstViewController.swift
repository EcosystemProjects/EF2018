//
//  firstViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 18.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class firstViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }

   

}
