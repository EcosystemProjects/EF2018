//
//  Category.swift
//  Ecosystem Feed
//
//  Created by Damla Karakulah on 20.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
import Alamofire
struct Category : Decodable {
    
    let id : String
    let name : String
    let orderindex : String
    let groupid : String
    let seourl:String
   // let follower : Follow
    let posts :String
  /*
    struct Follow :Decodable {
     let follower :Takip y da let follower:[Takip]
    }
    struct Takip :Decodable{
        let user:String
        let time :String
    }
 */
}


