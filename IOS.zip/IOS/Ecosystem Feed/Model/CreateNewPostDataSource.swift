//
//  CreateNewPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 21.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class CreateNewPostDataSource :NSObject{
   
    /*
    var authId:String!
    var image:String!
    var title:String!
    var aciklama:String!
    var seourl:String!
    */
  
    
    func createPost(authId:String,image:String,title:String,aciklama:String,seourl:String){
        
        
        let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=setPosts?")
        var request = URLRequest(url: urlString!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        /*
        request.setValue(authId, forHTTPHeaderField: "authid")
        request.setValue(image, forHTTPHeaderField: "image")
        request.setValue(title, forHTTPHeaderField: "title")
        request.setValue(aciklama, forHTTPHeaderField: "description")
        request.setValue(seourl, forHTTPHeaderField: "seourl")
        */
        request.httpMethod = "POST"
        
        let postString = "authId=\(authId)&image=\(image)&title=\(aciklama)&description=\(aciklama)&seourl=\(seourl)"
        request.httpBody = postString.data(using: .utf8)
        
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, response, error) in
           
            if let res = response as? HTTPURLResponse {
                print("response :",res.statusCode)
            }
            /*if let httpResponse = response as? HTTPURLResponse {
                print("statusCode: \(httpResponse.statusCode)")
            }
             */
        }
        dataTask.resume()
        
        
    }
    
    
    
}
