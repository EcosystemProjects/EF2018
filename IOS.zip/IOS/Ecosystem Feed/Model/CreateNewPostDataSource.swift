//
//  CreateNewPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 21.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class CreateNewPostDataSource :NSObject{
   
    /*
    var authId:String!
    var image:String!
    var title:String!
    var aciklama:String!
    var seourl:String!
    */
  
    
    func createPost(authId:String,resim:String,baslik:String,aciklama:String,seoUrl:String){
        
        if (authId == "") && (resim == "") && (baslik == "") && (aciklama == "") && (seoUrl == "") {
            print("GELEN PARAMETRELER BOŞ ..")
        }else{
    print("authid :",authId,"-","image :",resim,"-","title :",baslik,"-","aciklama :",aciklama,"-","seourl :",seoUrl)

            
        let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=setPosts")
       
        var request = URLRequest(url: urlString!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        //request.setValue("application/form-data", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
     //  request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let postString = "authid=EI-nUoWUuP&image=\(resim)&title=\(baslik)&description=\(aciklama)&seourl=\(seoUrl)"
       // let postString  = "authid=EI-nUoWUuP&image=a.jpg&title=deneme&description=bu bir deneme&seourl=Aydın"
        print("postString :>",postString)
        request.httpBody = postString.data(using: .utf8)
        
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, response, error) in
           guard let jsonData = data else {return }
            let dataAsString = String(data: jsonData,encoding:.utf8)
            print("jsonData :>",dataAsString!)
            if let res = response as? HTTPURLResponse {
                print("response :",res.statusCode)
               // print("data :>".data)
            }
            /*if let httpResponse = response as? HTTPURLResponse {
                print("statusCode: \(httpResponse.statusCode)")
            }
             */
            
        }
        dataTask.resume()
        
        
    }
        
    }
    
    
}
