//
//  NotificationDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 2.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class NotificationDataSource :NSObject{
    
    func notificaitonList(authID : String,userID:String)
    {
        
        if (authID == "") && (userID == ""){
            print("Boş Değer OLmaz...")
        }else{
            
        
        let session = URLSession.shared
        var request = URLRequest(url: URL(string: "http://ecosystemfeed.com/Service/Web.php?process=setOneSignalUser&authid=\(authID)&userid=\(userID)")!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let dataTask = session.dataTask(with: request) { (data, response, error) in
           
                // Print out reponse body
                if let jsonData = data {
                    let dataAsString = String(data: jsonData,encoding:.utf8)
                    print("jsonData :>",dataAsString!)
                }
            }
            dataTask.resume()
        }
        }
    
}

