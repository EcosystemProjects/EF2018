//
//  AllPostsDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 12.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
protocol FollowersDataDelegate {
    func followersListLoaded(getFollowList : [CategoriTakip])
}

extension FollowersDataDelegate{
    func followersListLoaded(getFollowList : [CategoriTakip]) { }
}

class FollowersDataSource : NSObject {
    
    var delegate : FollowersDataDelegate?
    //var urlString :URL?
    var url:String?
    func loadFollowersList(categoryFollow:String) 
    {
        if categoryFollow == " " {
            print("FOLLOW DA Takip edilecek olan category adı girilmemiş..")
        }
        else{
            print("categoryFollow :>",categoryFollow)
            url = "https://ecosystemfeed.com/Service/Web.php?process=getFollowers&seourl=\(categoryFollow)"
            let urlString = URL(string: url!)
           // print("urlString :>",urlString!)
           // print("urlString2 :>:>",URL(string: urlString)!)
          
                guard urlString != nil  else{
                   print("llib hatas var")
                    return
                }
 
          //  var request = URLRequest(url: URL(string: urlString)!)
           // if urlString != nil{
               
           
            var request = URLRequest(url :urlString!)
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpMethod = "GET"
            
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request) { (data, response, error) in
                /*if let response1 = response{
                    print(response1)
                }*/
                print("data :>",data!)
                do {
                    let followArray = try JSONDecoder().decode([CategoriTakip].self, from: data!)
                    print("followArray.count :>" ,followArray.count)
                   
                     if followArray.count == 0 {
                        print("followArray.count :>" ,followArray)
                    }else{
                        print("followArray :>",followArray)
                        self.delegate?.followersListLoaded(getFollowList: followArray)
                    }
                    
                    
                }
                catch{
                   // self.delegate?.followersListLoaded(getFollowList: [])
                    print("no follow")
                }
            }
            
            dataTask.resume()
          //  }
        //else{
                print("llib hatas var")
              /*  guard let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getFollowers&seourl=\(categoryFollow)") else{return}
                let session = URLSession.shared
                session.dataTask(with: url) { (data, response, error) in
                    guard let data = data else{return}
                    do{
                        let followArray = try JSONDecoder().decode([CategoriTakip].self, from: data)
                        print("followArray.count :>" ,followArray.count)
                    }catch{
                        print("nlib hatas var")
                    }
 
                }
           
                // print("Herhangi bir bilgi bulunmamaktadır..")
                */
           // }
    
          }
        
         
    }
    
}
