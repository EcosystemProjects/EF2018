//
//  AllPostsDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 12.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
protocol FollowersDataDelegate {
    func followersListLoaded(getFollowList : [CategoriTakip])
    func getFollowers(getFollowCount: [Int])
}

extension FollowersDataDelegate{
    func followersListLoaded(getFollowList : [CategoriTakip]) { }
    func getFollowers(getFollowCount: [Int]) { }
}

class FollowersDataSource : NSObject {
    
    var delegate : FollowersDataDelegate?
    var uzunluk:Int = 0
    var uzunlukAl :[Int] = []
    func loadFollowersList(categoryFollow:String) 
    {
        
        let session = URLSession.shared
        var request = URLRequest(url: URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getFollowers&seourl=\(categoryFollow)")!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            let decoder = JSONDecoder()
            do {
                let followArray = try decoder.decode([CategoriTakip].self, from: data!)
                
                if followArray.count != 0 {
                    self.uzunluk = followArray.count
                    print("self.uzunluk :",self.uzunluk)
                   self.uzunlukAl.append(self.uzunluk)
                    // print("categoryArray.count :>",categoryArray.count)
                    self.delegate?.followersListLoaded(getFollowList: followArray)
                    self.delegate?.getFollowers(getFollowCount: self.uzunlukAl)
                   
                }else{
                    print("categoryArray.count < 0 ")
                }
            }
            catch{
                self.delegate?.followersListLoaded(getFollowList: [])
               
                print("no categories")
            }
        }
        dataTask.resume()
        
         
    }
    
}
