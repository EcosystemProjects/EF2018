//
//  CreateNewPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 21.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

struct FollowDurum:Codable{
    let type:String
    let status:String
    
    private enum CodingKeys:String,CodingKey{
        case type = "type", status = "status"
        
    }
}
protocol TakipDurumuDelegate {
    func followDurum(durum:String)
}

extension TakipDurumuDelegate{
    func followDurum(durum:String){}
}
class CategoryFollowMeDataSource :NSObject{
    
    var delegete : TakipDurumuDelegate?
    var durum : String = ""
    func categoryFollowMe(authId:String,catid:String,type:String){
        
        if (authId == "")   && (catid == "") && (type == "") {
            print("GELEN PARAMETRELER BOŞ ..")
        }else{
           
            print("authid :",authId,"-","catid :",catid,"-","type :",type)
            
            let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=categoriesFollow&authid=\(authId)&catid=\(catid)&type=\(type)")
            
            var request = URLRequest(url: urlString!)
            request.httpMethod = "GET"
            
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            //request.setValue("application/form-data", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            //  request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            
            let postString = "authid=\(authId)&catid=\(catid)&type=\(type)"
           
            print("postString :>",postString)
            request.httpBody = postString.data(using: .utf8)
            
            
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request) { (data, response, error) in
                let decoder = JSONDecoder()
                 guard let jsonData = data else {return }
                do {
                    /*
                     if let res = response as? HTTPURLResponse {
                        print(" categoryFollowMe ; response :",res.statusCode)
                     // print("data :>".data)
                     
                     }
                     */
                    let dataAsString = String(data: jsonData,encoding:.utf8)
                    
                    if dataAsString == "" {print("Herhangi bir post bu kategoriye yapılmamış ki ..")}
                    else{
                        print("categoryFollowMe Durum :>",dataAsString!)
                        let followStatus = try decoder.decode(FollowDurum.self, from: data!)
                        print("followStatus.status :>",followStatus.status)
                        self.delegete?.followDurum(durum: followStatus.status)
                        
                       
                    }
                }
                catch{
                    self.delegete?.followDurum(durum: "")
                }
            }
            
            dataTask.resume()
    }
        
    }
    
}
