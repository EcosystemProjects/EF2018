//
//  MyPost.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 19.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
struct myPosts:Decodable{
    let title:String
    let description:String
    let image:String
    let date:String
    let shareurl:String
    let categoryid:String
    let category:String
    let ecosystem:String
    let region:String
    let seourl:String
    
}
