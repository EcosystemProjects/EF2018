//
//  User.swift
//  Ecosystem Feed
//
//  Created by Damla Karakulah on 20.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

struct User : Decodable {
    
    let id : String
    let information : String
   
}
