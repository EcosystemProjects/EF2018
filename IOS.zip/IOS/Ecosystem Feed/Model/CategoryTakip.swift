//
//  CategoryTakip.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 16.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

struct CategoriTakipNumber : Decodable {
    
    let name : String
    let surname : String
    let username : String
}
