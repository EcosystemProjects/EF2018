//
//  CategoryTakipSayisi.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 15.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
/*
struct CategoriTakipNumber : Decodable {
    
    let name : String
    let surname : String
    let username : String
}
*/
protocol CategoryTakipDelegate {
    func categoryNameFollowLength(categoryNameTakipUzunluk : Int)
}

extension CategoryTakipDelegate{
    func categoryNameFollowLength(categoryNameTakipUzunluk : Int) { }
}
class CategoryTakipSayisi : NSObject{
    
    var delegete : CategoryTakipDelegate?
    var getuzunluk:Int = 0
    
    func takipciler(categoryAdi:String){
        
        if categoryAdi == ""{
            print("Category adı girilmemiş veya gelmemiş..")
        }
        else{
            
            print("CategoryTakip Array da Category Adi :>",categoryAdi)
        guard let url1 = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getFollowers&seourl=\(categoryAdi)") else{return}
        
        var request = URLRequest(url: url1)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let session = URLSession.shared
        let dataTesk = session.dataTask(with: request) { (data, response, error) in
            
            guard let data = data else{return}
            do{
                
                let FollowUzunluk = try JSONDecoder().decode([CategoriTakipNumber].self, from: data)
                if FollowUzunluk.count != 0{
                    print("FollowUzunluk.count :>" ,FollowUzunluk.count)
                    self.delegete?.categoryNameFollowLength(categoryNameTakipUzunluk : FollowUzunluk.count)
                }
                
               /* if uzunluk.count != 0 {
                   // self.getuzunluk = self.self.uzunluk.count
                    self.setTakipciSayisi(u:uzunluk.count)
                }else{
                    
                    print("Servislerden veri alınamadı..")
                }
 */
                
            }catch{
                print("uzunluk alınamadı..Servislerden yanıt alınamamış olabilir..")
            }
            
        }
        dataTesk.resume()
        }
    }
    
    func setTakipciSayisi (u:Int) { self.getuzunluk = u}
    func getTakipciSayisi ()->Int {return self.getuzunluk}
    
}
