//
//  AllPosts.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 12.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

struct EcoFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
    // let category:String
    // let ecosystem:String
    // let region:String
    let shareurl:String
    
}
