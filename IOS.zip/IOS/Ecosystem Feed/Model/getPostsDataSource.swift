//
//  CategoryTakipSayisi.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 15.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
/*
struct CategoriTakipNumber : Decodable {
    
    let name : String
    let surname : String
    let username : String
}
*/
protocol getPostsDataDelegate {
    func getPostsDurum(getPostsDz: [getPostsData])
}

extension getPostsDataDelegate{
    func getPostsDurum(getPostsDz: [getPostsData]) { }
}
class getPostsDataSource : NSObject{
    
    var delegete : getPostsDataDelegate?
    var getuzunluk:Int = 0
    
    func getDataPosts(seoUrl:String){
        
        if seoUrl == ""{
            print("seourl parametresi girilmemiş veya gelmemiş..")
        }
        else{
            
            print("seoUrl :>",seoUrl)
        guard let url1 = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=\(seoUrl)") else{return}
        
        var request = URLRequest(url: url1)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let session = URLSession.shared
        let dataTesk = session.dataTask(with: request) { (data, response, error) in
            
            guard let data = data else{return}
            do{
                
                let getPostsUzunluk = try JSONDecoder().decode([getPostsData].self, from: data)
                if getPostsUzunluk.count != 0 {
                   // print("getPostsUzunluk :>" ,getPostsUzunluk.count)
                    self.delegete?.getPostsDurum(getPostsDz: getPostsUzunluk)
                }
                
               /* if uzunluk.count != 0 {
                   // self.getuzunluk = self.self.uzunluk.count
                    self.setTakipciSayisi(u:uzunluk.count)
                }else{
                    
                    print("Servislerden veri alınamadı..")
                }
 */
                
            }catch{
                print("Api verileri ile uyuşmazlık olmuş olabilir..")
            }
            
        }
        dataTesk.resume()
        }
    }
    
   
    
}
