//
//  MyPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 19.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
protocol MyPostDataDelegate {
    func myPostsListLoaded(mPostsList : [myPosts])
}

extension MyPostDataDelegate{
    func myPostsListLoaded(mPostsList : [myPosts]) { }
}
class MyPostDataSource:UIViewController{
    
    var delegate:MyPostDataDelegate?
    
    func myPostsList(authID : String)
    {
        
        let session = URLSession.shared
        
        var request = URLRequest(url: URL(string: "http://ecosystemfeed.com/Service/Web.php?process=getPostsMe&authid=EI-nUoWUuP")!) // (authID) gelicek..
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            let decoder = JSONDecoder()
            do {
                let myPostsListArray = try decoder.decode([myPosts].self, from: data!)
                
                self.delegate?.myPostsListLoaded(mPostsList: myPostsListArray)
            }
            catch{
                self.delegate?.myPostsListLoaded(mPostsList: [])
                print("no ecosystems")
            }
        }
        
        dataTask.resume()
    }
    
}
