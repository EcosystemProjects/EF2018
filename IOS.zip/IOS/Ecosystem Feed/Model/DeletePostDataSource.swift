//
//  DeletePostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 22.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

struct DeleteState:Codable{
    let function:String
    let status:String
    
    private enum CodingKeys:String,CodingKey{
        case function = "Function", status = "status"
        
    }
}
protocol DeletePost {
    func deleteStatus(durum:String)
    
}

extension DeletePost{
    func deleteStatus(durum:String) { }
    
}
class DeletePostDataSoUrce :NSObject{
    
    var delegate : DeletePost?
    func deletePost(authID:String,seoUrl:String){
        
        if ( authID == "" ) && ( seoUrl == "" ) {print("Boş Alan Beklemeyiniz..")}
        else{
        let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=deletePostsMe&authid=\(authID)&seourl=\(seoUrl)")
        var request = URLRequest(url: urlString!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       
        request.httpMethod = "GET"
    
        let decoder = JSONDecoder()
        let session = URLSession.shared

        let dataTask = session.dataTask(with: request) { (data, response, error) in
            
            guard let jsonData = data else { print("Delete işlemi Başarısız ..") ; return }
            let dataAsString = String(data: jsonData,encoding:.utf8)
            print("dataAsString :>",dataAsString!)
            do {
               // print("GELDİ.. DELETE")
                let deleteDurum = try decoder.decode(DeleteState.self, from: data!)
              //  print("jsonData :>",dataAsString!,"deleteDurum :>",deleteDurum.status)
                self.delegate?.deleteStatus(durum: deleteDurum.status)
            }catch
            {
                print("error :>",error)
            }
        }
        dataTask.resume()
        }
        
    }
}
