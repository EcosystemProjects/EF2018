//
//  DeletePostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 22.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class DeletePostDataSoUrce :NSObject{
    
    
    func deletePost(authID:String,seoUrl:String){
        
        let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=deletePostsMe&authid=\(authID)&seourl=\(seoUrl)")
        var request = URLRequest(url: urlString!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       
        request.httpMethod = "GET"
        
      /*  let postString = "authId=\(authID)&seourl=\(seoUrl)"
        request.httpBody = postString.data(using: .utf8)
        */
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            guard let jsonData = data else {return }
            let dataAsString = String(data: jsonData,encoding:.utf8)
            print("jsonData :>",dataAsString!)
            if let res = response as? HTTPURLResponse {
                print("response :",res.statusCode)
            }
            
        }
        dataTask.resume()
        
    }
}
