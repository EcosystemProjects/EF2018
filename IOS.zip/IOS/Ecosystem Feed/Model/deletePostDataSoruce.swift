//
//  deletePostDataSoruce.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class deletePostDataSoruce:NSObject{
    
    func deletePost(authId:String,seoUrl:String){
    if (authId == "") && (seoUrl == "") {
    print("GELEN PARAMETRELER BOŞ ..")
    }else{
   
    let urlString = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=setPosts")
    
    var request = URLRequest(url: urlString!)
    request.httpMethod = "POST"
    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
    //request.setValue("application/form-data", forHTTPHeaderField: "Content-Type")
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    //  request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
    
   /* let postString = "authid=EI-nUoWUuP&image=\(resim)&title=\(baslik)&description=\(aciklama)&seourl=\(seoUrl)"
    print("postString :>",postString)
 */
  //  request.httpBody = postString.data(using: .utf8)
    
    
    let session = URLSession.shared
    let dataTask = session.dataTask(with: request) { (data, response, error) in
    guard let jsonData = data else {return }
    let dataAsString = String(data: jsonData,encoding:.utf8)
    print("jsonData :>",dataAsString!)
    if let res = response as? HTTPURLResponse {
    print("response :",res.statusCode)
    // print("data :>".data)
    }
    /*if let httpResponse = response as? HTTPURLResponse {
     print("statusCode: \(httpResponse.statusCode)")
     }
     */
    
    }
    dataTask.resume()
    
    
    }
}
}
