//
//  CheckInternet.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 2.01.2019.
//  Copyright © 2019 Mansur Emin Kaya. All rights reserved.
//

import SystemConfiguration

public class CheckInternet{
    
    class func Connection() -> Bool{
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0,0,0,0,0,0,0,0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { zerroSocketAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zerroSocketAddress)
            }
        }
        
        var flags:SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!,&flags) == false {
            return false
        }
        
        // Working for Celluar and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        
        return ret
    }
}
