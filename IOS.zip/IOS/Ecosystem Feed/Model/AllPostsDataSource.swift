//
//  AllPostsDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 12.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
protocol PostsDataDelegate {
    func tumPostlar(getAllPostsList : [EcoFeed])
}

extension PostsDataDelegate{
    func tumPostlar(getAllPostsList : [EcoFeed]) { }
}

class AllPostsDataSource : NSObject {
    
    var delegate : PostsDataDelegate?
    
    func loadAllPostsList() //veriAl : String
    {
       
            
        let session = URLSession.shared
        
        var request = URLRequest(url: URL(string: "http://ecosystemfeed.com/Service/Web.php?process=getAllPosts")!)
            //getAllPosts
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        let dataTask = session.dataTask(with: request) { (data, response, error) in
            
            let decoder = JSONDecoder()
            
            do{
                let getAllPostsArray = try decoder.decode([EcoFeed].self, from: data!)
               // print("getAllPostsArray :>",getAllPostsArray,"---->" ,"getAllPostsArray.count :",getAllPostsArray.count)
                if getAllPostsArray.count != 0{
                    self.delegate?.tumPostlar(getAllPostsList: getAllPostsArray)
                }else{
                    print("Internetiniz yavaş olabilir veya sunucu zaman aşımına uğramış olabilir..")
                }
            }
            catch{
                print("no posts")
            }
            
        }
        
        dataTask.resume()
        
    }
    
}
