//
//  UserDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 4.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
import Alamofire

/*
struct LinkedinUser :Codable {
   
    let json:Nesne
}
struct Nesne :Codable {
    let emailAddress:String
    let firstName:String
    let lastName:String
    let publicProfileUrl:String
    let authId:String
    init(emailAddress: String, firstName: String, lastName: String,publicProfileUrl: String,authId: String) {
        self.emailAddress = emailAddress
        self.firstName = firstName
        self.lastName = lastName
        self.publicProfileUrl = publicProfileUrl
         self.authId = authId
    }
}
 */
protocol UserDataDelegate {
    var getAuthId: String { get set }
    func getUserMesaj(mesaj:String,sessionID:String)
   
}
extension UserDataDelegate{
    func getUserMesaj(mesaj:String,sessionID:String){}
}

class UserDataSource :NSObject ,UserDataDelegate {
    var getAuthId: String = ""
    
    
    var delegate : UserDataDelegate?
    var mesaj:String = ""
    var sorguUrl:String = ""
    var authID:String = ""
    var emailAddress:String = ""
    var firstName:String = ""
    var lastName:String = ""
    var publicProfileUrl:String = ""
    var authId:String = ""

   
   /* init(authId:String,firstName:String,lastName:String,emailAddress:String,publicProfileUrl:String) {
        
        self.authID = authId
        self.emailAddress = emailAddress
        self.firstName = firstName
        self.lastName = lastName
        self.publicProfileUrl = publicProfileUrl
    }
 */
    func userBilgileri(authId:String,firstName:String,lastName:String,emailAddress:String,publicProfileUrl:String){
        
        if (authId == "") && (firstName == "") && (lastName == "") && (emailAddress == "") && (publicProfileUrl == ""){
            print("Boş değer bırakmayın..")
        }
        else{
           
            self.authID = authId
            self.emailAddress = emailAddress
            self.firstName = firstName
            self.lastName = lastName
            self.publicProfileUrl = publicProfileUrl
            
            
           //let  anaUrl = "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json="
             sorguUrl = "{\"json\":{\"emailAddress\":\""+emailAddress+"\",\"firstName\":\""+firstName+"\",\"lastName\":\""+lastName+"\",\"publicProfileUrl\":\""+publicProfileUrl+"\",\"authId\":\""+authId+"\"}}"
        
            let txtSorguUrl = sorguUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)//Bu kod sayesinde hatamızı düzelttik..
           /*
           let obj = LinkedinUser(json: Nesne(emailAddress: emailAddress, firstName: firstName, lastName: lastName, publicProfileUrl: publicProfileUrl, authId: authId))
          
            
            let encoder = JSONEncoder()
           
            let json = try! encoder.encode(obj)
            let jsonString = String(data: json, encoding: .utf8)
   */
            if let url = URL(string: "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json=\(txtSorguUrl!)") {
                
                Alamofire.request(url).responseJSON { response in
                    
                    print("response :>",response)
                    
                    if let jsonArray = response.result.value{
                     
                     let jsonObject:Dictionary = jsonArray as! Dictionary<String,Any>
                        print("sessId :>",jsonObject["sessId"] as! String)
                        self.delegate?.getAuthId = jsonObject["sessId"] as! String
                        self.mesaj = jsonObject["message"] as! String
                        self.getAuthId = jsonObject["sessId"] as! String
                        self.delegate?.getUserMesaj(mesaj: self.mesaj,sessionID:jsonObject["sessId"] as! String)
                     }
                }
            }
            else{
                print("llib hatası : Çıkarılırken nil değeri döndü..")
            }
            
     }

    }

    // SessionId = AuthId değerini döndürür...
    func getSessionIdGetir() -> String{
        return self.getAuthId
    }
    
    
    // Bu Kısıma istenilen veriler gelmediğinden olmadı...(lastName,emailAddress değğerler..)
    func userInformation(){
        if (emailAddress == ""),(firstName == ""),(lastName == ""),(publicProfileUrl == ""),(authId == ""){
            print("BOŞ DEĞER OLMAZ..")
        }else{
            
       
        sorguUrl = "{\"json\":{\"emailAddress\":\""+emailAddress+"\",\"firstName\":\""+firstName+"\",\"lastName\":\""+lastName+"\",\"publicProfileUrl\":\""+publicProfileUrl+"\",\"authId\":\""+authId+"\"}}"
        
        print("sorguUrl Geldi :>",sorguUrl)
        
        let txtSorguUrl = sorguUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        
        if let url = URL(string: "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json=\(txtSorguUrl!)") {
            
            Alamofire.request(url).responseJSON { response in
                
                print("response :>",response)
                
                if let jsonArray = response.result.value{
                    
                    let jsonObject:Dictionary = jsonArray as! Dictionary<String,Any>
                    // print("sessId :>",jsonObject["sessId"] as! String)
                    self.mesaj = jsonObject["message"] as! String
                    self.delegate?.getUserMesaj(mesaj: self.mesaj,sessionID:jsonObject["sessId"] as! String)
                }
            }
        }
        else{
            print("llib hatası : Çıkarılırken nil değeri döndü..")
        }
    }
     }
}
