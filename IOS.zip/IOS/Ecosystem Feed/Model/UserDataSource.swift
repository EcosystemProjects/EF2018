//
//  UserDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 4.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
import Alamofire


struct LinkedinUser :Codable {
   
    let json:Nesne
}
struct Nesne :Codable {
    let authId:String
    let firstName:String
    let lastName:String
    let emailAddress:String
    let publicProfileUrl:String
    
    init(authId: String, firstName: String, lastName: String,emailAddress: String,publicProfileUrl: String) {
        self.authId = authId
        self.firstName = firstName
        self.lastName = lastName
        self.emailAddress = emailAddress
        self.publicProfileUrl = publicProfileUrl
    }
}
protocol UserDataDelegate {
    func UserInformation(getUser : User)
}
extension UserDataDelegate{
    func UserInformation(getUser : User){}
}

class UserDataSource  {
    
    var deleagte : UserDataDelegate?
    
func userBilgileri(authId:String,firstName:String,lastName:String,emailAddress:String,publicProfileUrl:String){
        
        if (authId == "") && (firstName == "") && (lastName == "") && (emailAddress == "") && (publicProfileUrl == ""){
            print("Boş değer bırakmayın..")
        }
        else{
           // let string = "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json={"+"\"json\""+":{" + "\"emailAddress\":"+"\"kayamansur61@gmail.com\"," + "\"firstName\":"+"\"mansur emin\"," + "\"lastName\":"+"\"kaya\"," + "\"publicProfileUrl\":"+"\"https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM\"," + "\"authId\":"+"\"S7UA261fjN\""+"}}"
            
            //let baseUrl = "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json={\"json\":"
           // let query = "{\"json\":{\"emailAddress\":\""+emailAddress+"\",\"firstName\":\""+firstName+"\",\"lastName\":\""+lastName+"\",\"publicProfileUrl\":\""+publicProfileUrl+"\",\"authId\":\""+authId+"\"}}"
        
           // print("query :>",query)
            
           
           
            let obj = LinkedinUser(json: Nesne(authId: authId, firstName: firstName, lastName: lastName, emailAddress: emailAddress, publicProfileUrl: publicProfileUrl))
            
            
            let encoder = JSONEncoder()
           
            let json = try! encoder.encode(obj)
            let jsonString = String(data: json, encoding: .utf8)
            
            print("jsonString :>",jsonString!)

        /*
            Alamofire.request(URL(string: "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json="+jsonString!)!).responseJSON { response in
                print(response)
               
                /*if let jsonArray = response.result.value{
                    
                    let jsonObject:Dictionary = jsonArray as! Dictionary<String,Any>
                     print(jsonObject)
                    
                }*/
            }
          
           */
        
            
     }
    }
    
}
