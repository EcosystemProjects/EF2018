//
//  CategroyFollowMe.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 26.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
struct CategoryFollowMe:Decodable {
    
    let Function:String
    let status:String
    let categories:[Categories]
    
    struct Categories:Decodable {
        let id:String
        let name:String
        let seourl:String
    }
}
