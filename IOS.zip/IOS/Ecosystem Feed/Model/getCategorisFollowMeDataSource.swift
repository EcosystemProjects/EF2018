//
//  DetayPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 16.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
import Alamofire
protocol getCategorisFollowMeDelegete {
    func getCategoryFollowMe(getCategoryFMe : [CategoryFollowMe])
    func getCategoryFollowMe2(getCategoryFMe : [Any])
}

extension getCategorisFollowMeDelegete{
    func getCategoryFollowMe(getCategoryFMe : [CategoryFollowMe]) { }
    func getCategoryFollowMe2(getCategoryFMe : [Any]){ }
}

class getCategorisFollowMeDataSource : NSObject {
    
    var delegate : getCategorisFollowMeDelegete?
    var dz:[Any] =  []
    var sayac:Int = 0
    
    func followMeCategory(authID : String)
    {
        if authID == ""{
             print(" authID değeri boş ")
           }
        else{
           
            print(" authID değeri :>:> ",authID)
            Alamofire.request(URL(string: "http://ecosystemfeed.com/Service/Web.php?process=getMeFollowCategories&authid=\(authID)")!).responseJSON { response in
               // print(response)
                if let jsonArray = response.result.value{
                    
                    let jsonObject:Dictionary = jsonArray as! Dictionary<String,Any>
                    // print(jsonObject)
                    print("jsonObject :>",jsonObject.count)
                    guard let categoriArray:[Any] = jsonObject["categories"] as? [Any] else{return}
                    //print("categoriArray ",categoriArray)
                    
                    //let categoriArrayObject:Dictionary = categoriArray[0] as! Dictionary<String,Any>
                    // print("categoriArrayObject ",categoriArrayObject)
                    if categoriArray.count > 0 {
                        for i in 0...(categoriArray.count-1){
                            
                            let categoriArrayObject:Dictionary = categoriArray[i] as! Dictionary<String,Any>
                            
                            while self.sayac < (categoriArrayObject.count-1){
                                let name:String = categoriArrayObject["name"] as! String
                                self.dz.append(name)
                                // self.dz[self.sayac] = name
                                self.sayac += 1
                                break
                                
                            }
                            
                        }
                        self.delegate?.getCategoryFollowMe2(getCategoryFMe: self.dz)
                        
                        
                        /*
                         Bu for dz elemanlarını bastırır
                         
                         for i in 0...(self.dz.count-1){
                         print("dz[\(i)] :>",self.dz[i])
                         }
                         */
                    }else{
                        print("Herhangi Bir Categori takip edilmemiş..")
                        
                    }
                    
                }
            }
            
            
            
            
            
            
            /*
            let urlString = "https://ecosystemfeed.com/Service/Web.php?process=getMeFollowCategories&authid=\(authID)"
                                                                        EI-nUoWUuP
            guard URL(string: urlString) != nil else{
                print("llib hatası var")
                return
            }
            var request = URLRequest(url: URL(string: urlString)!)
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpMethod = "GET"
            
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request) { (data, response, error) in
                let decoder = JSONDecoder()
                do {
                    
                    if let jsonData = data{
                        
                        let dataAsString = String(data: jsonData,encoding:.utf8)
                        print("dataAsString :>",dataAsString!)
                        
                        let CatfollowmeArray = try decoder.decode([CategoryFollowMe].self, from: data!)
                       
                        if CatfollowmeArray.count > 0 {
                            
                            print("CatfollowmeArray :>",CatfollowmeArray)
                            self.delegate?.getCategoryFollowMe(getCategoryFMe: CatfollowmeArray)
                       
                        }
                    }
                
                }
                catch{
                    self.delegate?.getCategoryFollowMe(getCategoryFMe: [])
                    print("no categories follow me")
                }
            }
            
            dataTask.resume()
            */
        }
    }
    
}
