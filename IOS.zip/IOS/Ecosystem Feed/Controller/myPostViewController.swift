//
//  myPostViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 1.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

struct EcosystemFeedKullanimi:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
    let category:String
    let ecosystem:String
    let region:String
    let shareurl:String
    
}

class myPostViewController: UIViewController{


    @IBOutlet weak var labelYazilar: UILabel!
    @IBOutlet weak var resim: UIImageView!

     var titleEcosystemFeed : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.labelYazilar.text =
            showMyPost()
    }

    @IBAction func create(_ sender: Any) {
        performSegue(withIdentifier: "cr", sender: nil)

    }
    
    
    func showMyPost()/*->String*/{
         let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=Mugla")
        let urlSession = URLSession.shared
        urlSession.dataTask(with: (url)!) { (data, response, error) in
           /* if let response = response{
                print(response)
            }
            */
            guard let data = data else {return}
            print("data", data)
            
            
            
            do{
                
                //let json = try JSONSerialization.jsonObject(with: data, options: [])
                let json = try JSONDecoder().decode([EcosystemFeedKullanimi].self,from: data)
                print(json[0].title)
                //self.titleEcosystemFeed = json[0].title
                //print("titleEcosystemFeed -> ",self.titleEcosystemFeed)
                
                self.labelYazilar.text = json[0].region + "-" + json[0].ecosystem + "-" + json[0].category
                self.resim.image = UIImage(named: "maxresdefault.jpg")
                
                
                //print(json)
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
        //return titleEcosystemFeed
    }
}
