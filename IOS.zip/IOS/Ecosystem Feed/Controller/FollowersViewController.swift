//
//  FollowersViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class FollowersViewController :UIViewController ,/*,UITableViewDelegate,UITableViewDataSource,*/FollowersDataDelegate{
   
    //@IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var mScrolView: UIScrollView!
    @IBOutlet weak var eklemeView: UIView!
    let dataSource = FollowersDataSource()
    var takipciArrray : [CategoriTakip] = []
    var categoryName : String = ""
    
    
    override func viewDidLoad() {
       
       self.dataSource.delegate=self
         super.viewDidLoad()
    }
   
    override func viewWillAppear(_ animated: Bool) {
        print("categoryName -->",self.categoryName)
        dataSource.loadFollowersList(categoryFollow: self.categoryName)
    }
    
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func followersListLoaded(getFollowList: [CategoriTakip]) {
       
        self.takipciArrray=getFollowList
        print(" self.takipciArrray :>" ,self.takipciArrray)
        setButtons()
       /* DispatchQueue.main.async {
            self.tableview.reloadData()
        }
        */
        //print("self.takipciArrray --->",self.takipciArrray," ve ", "getFollowList --->",getFollowList," ve ","self.takipciArrray.count --->",self.takipciArrray.count)
    }
   
    func setButtons(){
        DispatchQueue.main.async {
           
            let numberOfButtons = self.takipciArrray.count
            let px = self.eklemeView.center.x
           
            var py = 150
            if(self.takipciArrray.count == 0){
                return
            }
            for count in 0...numberOfButtons-1 {
                
                let button = UIButton()
                button.tag = count
                button.frame = CGRect(x:  Int(px)-(Int(self.mScrolView.contentSize.width-90)/2), y:py, width: Int(self.mScrolView.contentSize.width-90), height: 45)
                button.backgroundColor = UIColor.lightGray
                button.setTitle("\(self.self.takipciArrray[count].name)", for: .normal)
                button.layer.cornerRadius = 9
                
                //button.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
                self.mScrolView.addSubview(button)
                py += 50
            }
        }
    }
    
    
    
    
    
    
    
   /* func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
 
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if takipciArrray.count > 0{
             return takipciArrray.count
        }
        else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let follow_Cell = tableView.dequeueReusableCell(withIdentifier: "followCell", for: indexPath) as! FollowersViewCell
      
        if takipciArrray.count > 0{
            follow_Cell.lblUserName?.text = takipciArrray[indexPath.row].name
             return follow_Cell
        }
        else{
            follow_Cell.lblUserName?.text = " " //Sunucu yavaş çalışıyor olabilir.
            return follow_Cell
        }
       
        // follow_Cell.imgProfil? = self.imgArray[indexPath.row]
        //follow_Cell.imgProfil?.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+json[0].image))!))
        
        
    
    }
    var sayac :Int=0
    func getAllPostVeriDondur()  {
        
        var request = URLRequest(url: URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        let urlSession = URLSession.shared
        
        urlSession.dataTask(with: request) { (data, response, error) in
            
            /* if let response = response{
             print(response)
             }
             */
            guard let data = data else {return}
            //print("data", data)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
                // self.degerAlAta = json[0].title
                while self.sayac < json.count{
                    //self.veriAl(deger:json[self.sayac].title,uzunluk: json.count,resim:json[self.sayac].image)
                    
                    print("self.sayac :",self.sayac)
                    self.sayac += 1
                }
                
                
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
    }
    */
  
    
}
