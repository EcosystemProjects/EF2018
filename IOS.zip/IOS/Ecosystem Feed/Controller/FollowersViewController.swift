//
//  FollowersViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class FollowersViewController :UIViewController ,FollowersDataDelegate{
   
    
   
    @IBOutlet weak var scrolView: UIScrollView!
    let dataSource = FollowersDataSource()
    var takipciArrray : [CategoriTakip] = []
    var categoryName : String = ""
    
    @IBOutlet weak var takipedilenCategoriAdi: UILabel!
    
    override func viewDidLoad() {
      // self.tableview.rowHeight = 80;
       self.dataSource.delegate=self
        self.takipedilenCategoriAdi.text! = "Categori : \(self.categoryName)"
         super.viewDidLoad()
       
    }
   
    override func viewWillAppear(_ animated: Bool) {
        print("categoryName -->",self.categoryName)
        print("categoryName followda :>",categoryName)
        dataSource.loadFollowersList(categoryFollow: self.categoryName)
    }
    
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
   
    func followersListLoaded(getFollowList: [CategoriTakip]) {
       
        self.takipciArrray=getFollowList
       // print(" self.takipciArrray :>" ,self.takipciArrray)
        print(" self.takipciArrray.count :>" ,self.takipciArrray.count)
        setButtons()
       
        /*DispatchQueue.main.async {
            
        }
        */
       
    }
    
    
    func setButtons(){
        
        if self.takipciArrray.count > 0 {
             DispatchQueue.main.async {
                
                let numberOfButtons = self.takipciArrray.count
               
                let px = self.scrolView.center.x
                print( "px :>",px)
                var py = 150
               
                for count in 0...numberOfButtons-1 {
                    
                    let button = UIButton()
                    button.tag = count
                    button.frame = CGRect(x:  Int(px)-(Int(self.scrolView.contentSize.width-90)/2), y:py, width: Int(self.scrolView.contentSize.width-90), height: 45)
                    button.backgroundColor = UIColor.lightGray
                    button.setTitle("\(self.self.takipciArrray[count].name)", for: .normal)
                    button.layer.cornerRadius = 9
                    
                  //  button.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
                    self.scrolView.addSubview(button)
                    py += 50
                }
               }
        }else{
            
           print("Herhangi bir follow yapılmamış")
        }
    }
    
    
    
    
    
    
   
    
}
