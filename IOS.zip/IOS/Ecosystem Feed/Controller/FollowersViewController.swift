//
//  FollowersViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
import UIKit

class FollowersViewController :UIViewController ,UITableViewDataSource,UITableViewDelegate ,FollowersDataDelegate{
   
    
    @IBOutlet weak var scrolView: UIScrollView!
    let dataSource = FollowersDataSource()
    var takipciArrray : [CategoriTakip] = []
    var categoryName : String = ""
    
    @IBOutlet weak var takipedilenCategoriAdi: UILabel!
     @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
      // self.tableview.rowHeight = 80;
       self.dataSource.delegate=self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.takipedilenCategoriAdi.text! = "Categori : \(self.categoryName)"
         super.viewDidLoad()
       
    }
   
    override func viewWillAppear(_ animated: Bool) {
        print("categoryName -->",self.categoryName)
        print("categoryName followda :>",categoryName)
        dataSource.loadFollowersList(categoryFollow: self.categoryName)
    }
    
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
   
   
    func followersListLoaded(getFollowList: [CategoriTakip]) {
       
        self.takipciArrray=getFollowList
       // print(" self.takipciArrray :>" ,self.takipciArrray)
        print(" self.takipciArrray.count :>" ,self.takipciArrray.count)
      //  setButtons()
       
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
       
    }
    
    
    func setButtons(){
        
        if self.takipciArrray.count > 0 {
             DispatchQueue.main.async {
                
                let numberOfButtons = self.takipciArrray.count
               
                let px = self.scrolView.center.x
                print( "px :>",px)
                var py = 150
               
                for count in 0...numberOfButtons-1 {
                    
                    let button = UIButton()
                    button.tag = count
                    button.frame = CGRect(x:  Int(px)-(Int(self.scrolView.contentSize.width-90)/2), y:py, width: Int(self.scrolView.contentSize.width-90), height: 45)
                    button.backgroundColor = UIColor.lightGray
                    button.setTitle("\(self.self.takipciArrray[count].name)", for: .normal)
                    button.layer.cornerRadius = 9
                    
                  //  button.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
                    self.scrolView.addSubview(button)
                    py += 50
                }
               }
        }else{
            
           print("Herhangi bir follow yapılmamış")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return takipciArrray.count
        
    }
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "followerCell", for: indexPath) as! FollowersCell
        
        if takipciArrray.count > 0 {
            cell.followName.setTitle(takipciArrray[indexPath.row].name, for: .normal)
            
        }
       
        return cell
        
    }
    
    
    
    
    
    
   
    
}
