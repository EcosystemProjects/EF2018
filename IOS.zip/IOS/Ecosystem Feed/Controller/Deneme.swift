//
//  Deneme.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

struct EcosystemFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
    let category:String
    let ecosystem:String
    let region:String
    let shareurl:String
    
}
class Deneme: UIViewController , UICollectionViewDelegate,UICollectionViewDataSource{
    //@IBOutlet weak var showMyPostBtn: UIButton!
    
   // let imgArray = [UIImage(named: "dolunaydayururkenVQ054"),UIImage(named: "maxresdefault")]
   //
    let nameArray = ["dolunay","oludeniz"]
    let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]

    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //web servisten dönen uzunluk dönmeli
        return imgArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "cellParca1", for: indexPath) as!  cellParca
        //cell.imgImage.image = imgArray[indexPath.row]
      //  cell.lbl.text! = nameArray[indexPath.row]
        
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=Mugla")
        
        let urlSession = URLSession.shared
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             //print(response)
             
             }*/
            
            guard let data = data else {return}
            print("data", data)
            print("indexPath :", indexPath)
            do{
                let json = try JSONDecoder().decode([EcosystemFeed].self,from: data)
                
                print("indexPath.row :", indexPath.row)
                
                cell.lbl.text! = json[indexPath.row].region + "-"+json[indexPath.row].ecosystem+"-"+json[indexPath.row].category+"\n"+json[indexPath.row].title
                cell.descriptionAlani.text! = json[indexPath.row].description
                cell.imgImage.image = self.imgArray[indexPath.row]
                
                //a). cell.imgImage.image = UIImage(named: "https://ecosystemfeed.com\(json[indexPath.row].image)")
                //b). cell.imgImage.image = UIImage(named:"\(json[indexPath.row].image)")
                // a ve b kısım neden olmuyor onu araştırıyorum mantıklı olan bu alanların çalışmasıdır..
                
                
                print(" sıra \(indexPath.row)")
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
        //cell.postUudiLabel.isHidden = true
        
        
        return cell
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
