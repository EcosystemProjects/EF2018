//
//  contaViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 22.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class contaViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

   
    

}
