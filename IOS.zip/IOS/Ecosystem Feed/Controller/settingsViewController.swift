//
//  settingsViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 20.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import OneSignal
class settingsViewController: UIViewController ,UIPickerViewDelegate,UIPickerViewDataSource{
    
    @IBOutlet var secilenDiliGoster :UILabel!
    let diller = ["English","Turkish","French","German"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    @IBOutlet var switchEmail:UISwitch!
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
       return  diller.count //picker view da gözükecek elemanlarımın toplam uzunluğu
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return diller[row] // picker view da gözükecek elemanlarım
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        secilenDiliGoster.text = diller[row] // picker view daki elemanlarımın gösterileceği yer
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        switchEmail.isOn = false
        /*
         let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
        
        let userID = status.subscriptionStatus.userId
        print("userID = \(userID)")
        */
    }
    
    @IBAction func NotificationSwitch(_ sender: UISwitch) {
        if (sender.isOn == true ){
            //buraya notificaiton salıp almama durumu yazılacak
            
            OneSignal.postNotification(["contents": ["en": "Test Message"], "include_player_ids": ["3009e210-3166-11e5-bc1b-db44eb02b120"]])
        }else{
            
        }
    }
    
    @IBAction func eMailSwitch(_ sender: UISwitch) {
        if (sender.isOn == true ){
            //buraya email alıp almama durumu yazılacak
            
            let emailAuthHash = "http://ecosystemfeed.com"//generated on your backend server
            let email = "kayamansur61@gmail.com";
            OneSignal.setEmail(email, withEmailAuthHashToken: emailAuthHash, withSuccess: {
                //The email has successfully been set.
            }) { (error) in
                //Encountered an error while setting the email.
                print("error :>" ,error!)
            };
            
            
        }else{
            OneSignal.logoutEmail()
           
        }
    }
    @IBAction func logOut1(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "user")
        UserDefaults.standard.synchronize()
        
        let SignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUp") as? ViewController
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = SignUp
        delegate.rememberLogin()
    }
    
    
   
    

}
