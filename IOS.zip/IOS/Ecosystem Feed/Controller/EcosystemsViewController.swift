//
//  regionViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 23.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class EcosystemsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, EcosystemDataDelegate {

    
    @IBOutlet weak var tableView: UITableView!
    let dataSource = EcosystemDataSource()
    var ecosystemArray : [Ecosystem] = []
    var colorArray : [UIColor] = []
    var selectedRegion : String = ""
    var selectedEcosystem : String = ""
    var selectedEcosystemName : String = ""
    var authIDAl :String = ""

    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource.delegate = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        print("Ulaa -> self.selectedRegion :>",self.selectedRegion)
        print("Ecosystem self.authID :>",self.authIDAl)
        dataSource.loadEcosystemList(groupid: self.selectedRegion)
      
    }
    
    func ecosystemListLoaded(ecosystemList: [Ecosystem]) {
        self.ecosystemArray = ecosystemList
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
      
    }
    
    @objc func scrollButtonAction(sender: UIButton) {
        print("\(ecosystemArray[sender.tag].name) is Selected")
        self.selectedEcosystem = ecosystemArray[sender.tag].id
        self.selectedEcosystemName = ecosystemArray[sender.tag].name
        performSegue(withIdentifier: "Categories", sender: self)
    }
    
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if ecosystemArray.count != 0 {
            return ecosystemArray.count
        }else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ecoViewCell", for: indexPath) as! EcosystemCell
        
        cell.ecosystemName.tag = indexPath.row
        if ecosystemArray.count > 0 {
            cell.ecosystemName.setTitle(ecosystemArray[indexPath.row].name, for: .normal)
            cell.ecosystemName.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
        }else{
            alertMesaj()
        }
        
        return cell
        
    }
    func alertMesaj(){
        let alert = UIAlertController(title: "Ecosystem Durum", message: "Ecosystem Bulunmamaktadır..", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is AllCategoriesViewController){
            let categoriesController = segue.destination as! AllCategoriesViewController
            categoriesController.selectedEcosystem = self.selectedEcosystem
            categoriesController.selectedEcosystemName = self.selectedEcosystemName
            categoriesController.authIdAl = self.authIDAl
        }
        else{
            print("error occured")
        }
        
    }
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    

}
