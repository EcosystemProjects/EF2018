//
//  AllCategoriesViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 27.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import Foundation

class AllCategoriesViewController : UIViewController,CategoryDataDelegate ,PostsDataDelegate{
    
    @IBOutlet weak var eklemeView: UIView!
    @IBOutlet weak var ecosystemNameLabel: UILabel!
    @IBOutlet var  mScrollView:UIScrollView!
    //let takipciSayisi = CategoryTakipSayisi()
    let dataSource = CategoryDataSource()
    var categoryDataSource = CategoryFollowMeDataSource()
    let allDataSource = AllPostsDataSource()
    var categoryArray : [Category] = []
    var allPostDz :[EcoFeed] = []
    var selectedEcosystem: String = ""
    var selectedEcosystemName : String = ""
    var sayac = 0
    var categoryNameFollowCount :Int = 0
    var categoryNameGetir : String = ""
    var nameAl:[String] = []
    var cateegoryIdAl : [String] = []
    
   
    func categoryListLoaded(categoryList: [Category]) {
        self.categoryArray = categoryList
        print("self.categoryArray :>",self.categoryArray)
       setButtons()
        DispatchQueue.main.async {
            self.ecosystemNameLabel.text = "\(self.selectedEcosystemName)"
            //self.tableView.reloadData()
        }
      
    }
    func tumPostlar(getAllPostsList: [EcoFeed]) {
        self.allPostDz = getAllPostsList
        print("self.allPostDz :> ",self.allPostDz)
    }
    override func viewDidLoad() {
        self.title = "Categories"
        self.dataSource.delegate = self
        allDataSource.delegate = self
       //self.tableView?.rowHeight = 135
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        print("ULAAA -> self.selectedEcosystem :>",self.selectedEcosystem)
        dataSource.loadCategoryList(groupid: self.selectedEcosystem)
        allDataSource.loadAllPostsList()
        
    }
    @objc func scrollBtnPostAction(sender: UIButton) {
        print("sender.tag :>",sender.tag)
        
    }
    @objc func scrollBtnFollowersAction(sender: UIButton) {
        print("sender.tag :>",sender.tag)
        print("sendder[\(sender.tag)] :",categoryArray[sender.tag].name)
        self.categoryNameGetir = categoryArray[sender.tag].name
        performSegue(withIdentifier: "Follow", sender: self)
    }
    @objc func scrollBtnFollowAction(sender: UIButton) {
         print("sender.tag :>",sender.tag)
        
        for i in 0...self.allPostDz.count{
            if categoryArray[sender.tag].name == allPostDz[i].category{
                
                categoryDataSource.categoryFollowMe(authId: "EI-nUoWUuP", catid: "\(allPostDz[i].categoryid)", type: "follow")
                
                break
            }
            
        }
    }
    @objc func scrollBtnUnFollowMeAction(sender: UIButton) {
        print("sender.tag :>",sender.tag)
    
        for i in 0...self.allPostDz.count{
            if categoryArray[sender.tag].name == allPostDz[i].category{
                
                categoryDataSource.categoryFollowMe(authId: "EI-nUoWUuP", catid: "\(allPostDz[i].categoryid)", type: "unfollow")
                
                break
            }
            
        }
    }
    @objc func scrollBtnFollowMeAction(sender: UIButton) {
        print("sender.tag :>",sender.tag)
      
        performSegue(withIdentifier: "CategoriesFollowMe", sender: self)
        
    }
    func setButtons(){
    print("GELDİ.","-","self.categoryArray.count :>",self.categoryArray.count)
        DispatchQueue.main.async {
            
            let numberOfButtons = self.categoryArray.count
            let px = self.mScrollView.center.x
            var py = 150
            if(self.categoryArray.count == 0){
                return
            }
            for count in 0...numberOfButtons-1 {
                // Nesnelerim
                let buttonPost = UIButton()
                let categoryName = UILabel()
                let btnFollowers = UIButton()
                let btnFollow = UIButton()
                let btnFollowerMeCategroy = UIButton()
                let btnUnFollow = UIButton()
                // nesne index uzunluklarımın toplamı
                btnFollowers.tag = count
                buttonPost.tag = count
                categoryName.tag = count
                btnFollow.tag = count
                btnFollowerMeCategroy.tag = count
                btnUnFollow.tag = count
                // buttonPost özellikleri
                buttonPost.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-20)/2), y:py+30, width: /*Int(self.mScrollView.contentSize.width-90)*/80, height: 30)
                buttonPost.backgroundColor = UIColor.white
                buttonPost.setTitleColor(UIColor.blue, for: .normal)
                buttonPost.setTitle("\(self.self.categoryArray[count].posts) Posts", for: .normal)
                
                
                // categoryName özellikleri
                categoryName.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-30)/2),           y:py-30,width: Int(self.mScrollView.contentSize.width-90), height: 90)
                categoryName.text = "\(self.categoryArray[count].name)"
                
                // btnFollow özellikleri
                btnFollowers.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-200)/2), y:py+30, width: /*Int(self.mScrollView.contentSize.width-90)*/110, height: 30)
                btnFollowers.backgroundColor = UIColor.white
                btnFollowers.setTitleColor(UIColor.blue, for: .normal)
                btnFollowers.setTitle("\(self.self.categoryArray[count].posts) Followers", for: .normal)
              
                
                // btnFollowers özellikleri
                btnFollow.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-440)/2), y:py+20, width: /*Int(self.mScrollView.contentSize.width-90)*/85, height: 25)
                btnFollow.backgroundColor = UIColor.lightGray
                btnFollow.setTitleColor(UIColor.black, for: .normal)
                btnFollow.setTitle(" FOLLOW ", for: .normal)
                btnFollow.layer.cornerRadius = 9
               
                // btnUnFollowers özellikleri
                btnUnFollow.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-440)/2), y:py+45, width: /*Int(self.mScrollView.contentSize.width-90)*/85, height: 25)
                btnUnFollow.backgroundColor = UIColor.lightGray
                btnUnFollow.setTitleColor(UIColor.black, for: .normal)
                btnUnFollow.setTitle("UN FOLLOW ", for: .normal)
                btnUnFollow.layer.cornerRadius = 9
                
                // btnFollowerMeCategroy özellikleri
                btnFollowerMeCategroy.frame = CGRect(x:  Int(px)-(Int(self.mScrollView.contentSize.width-630)/2), y:py+20, width: /*Int(self.mScrollView.contentSize.width-90)*/90, height: 50)
                btnFollowerMeCategroy.backgroundColor = UIColor.lightGray
                btnFollowerMeCategroy.setTitleColor(UIColor.black, for: .normal)
                btnFollowerMeCategroy.setTitle("Follow Me", for: .normal)
                btnFollowerMeCategroy.layer.cornerRadius = 9
               // btnFollowerMeCategroy.layer.borderColor = UIColor.red.cgColor
                
                // mScrollView ekleme kısmı
                self.mScrollView.addSubview(categoryName)
                self.mScrollView.addSubview(buttonPost)
                self.mScrollView.addSubview(btnFollowers)
                self.mScrollView.addSubview(btnFollow)
                self.mScrollView.addSubview(btnFollowerMeCategroy)
                self.mScrollView.addSubview(btnUnFollow)
                  // mScrollView eklenen yapılara action özelliği verme
                buttonPost.addTarget(self, action: #selector(self.scrollBtnPostAction), for: .touchUpInside)
                btnFollowers.addTarget(self, action: #selector(self.scrollBtnFollowersAction), for: .touchUpInside)
                btnFollow.addTarget(self, action: #selector(self.scrollBtnFollowAction), for: .touchUpInside)
                btnFollowerMeCategroy.addTarget(self, action: #selector(self.scrollBtnFollowMeAction), for: .touchUpInside)
                btnUnFollow.addTarget(self, action: #selector(self.scrollBtnUnFollowMeAction), for: .touchUpInside)

                
                py += 80
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is CategoryFollowMeViewController){
            let categoriesController = segue.destination as! CategoryFollowMeViewController
            categoriesController.authID = "EI-nUoWUuP"
        }else if (segue.destination is FollowersViewController){
            let followersController = segue.destination as! FollowersViewController
            followersController.categoryName = self.categoryNameGetir
        }
        else{
            print("error occured")
        }
        
    }
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }

    
}
