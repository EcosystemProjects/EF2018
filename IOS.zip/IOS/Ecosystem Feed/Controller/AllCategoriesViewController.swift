//
//  AllCategoriesViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 27.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import Foundation

class AllCategoriesViewController : UIViewController,UITableViewDelegate,UITableViewDataSource,CategoryDataDelegate ,PostsDataDelegate,TakipDurumuDelegate {
    
    @IBOutlet weak var ecosystemNameLabel: UILabel!
   
    let dataSource = CategoryDataSource()
    
    let allDataSource = AllPostsDataSource()
    let followMeState = CategoryFollowMeDataSource()
    var followState:String = ""
    var categoryArray : [Category] = []
    
    var followUzunluk:[Int] = []
    var getCategoryArray :[[String:Any]] = [[:]]
    var authIdAl:String = ""
    var allPostDz :[EcoFeed] = []
    var selectedEcosystem: String = ""
    var selectedEcosystemName : String = ""
    var sayac = 0
    var categoryNameFollowCount :Int = 0
    var categoryNameGetir : String = ""
    var seoUrlGetir : String = ""
    var nameAl:[String] = []
    var cateegoryIdAl : [String] = []
    
    func getCategoriesList(getcategoryList: [[String:Any]]) {
        self.getCategoryArray = getcategoryList
      //  print("self.getCategoryArray :>",self.getCategoryArray)
    
    }
    func getFollowers(getFollowCount: [Int]) {
        self.followUzunluk=getFollowCount
        print("self.followUzunluk :>",self.followUzunluk)
    }
    
    @IBOutlet weak var tableView: UITableView!
    func categoryListLoaded(categoryList: [Category]) {
        self.categoryArray = categoryList
       
        DispatchQueue.main.async {
            self.ecosystemNameLabel.text = "\(self.selectedEcosystemName)"
            self.tableView.reloadData()
        }
      
    }
 
    func tumPostlar(getAllPostsList: [EcoFeed]) {
        self.allPostDz = getAllPostsList
        //print("self.allPostDz :> ",self.allPostDz)
    }
    override func viewDidLoad() {
        self.title = "Categories"
        self.dataSource.delegate = self
        allDataSource.delegate = self
        self.followMeState.delegete = self
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func followDurum(durum: String) {
        self.followState = durum
        print("self.followState :>",self.followState)
        self.alertMesaj(title:"Follow Durumu", mesaj: followState)
    }

    override func viewWillAppear(_ animated: Bool) {
        print("AllCategoriesViewController self.authIdAl :>",self.authIdAl)
        print("ULAAA -> self.selectedEcosystem :>",self.selectedEcosystem)
        dataSource.loadCategoryList(groupid: self.selectedEcosystem)
        allDataSource.loadAllPostsList()
        
    }
    @objc func scrollBtnPostAction(sender: UIButton) {                  //POSTS
        print("sender.tag :>",sender.tag)
        self.seoUrlGetir = categoryArray[sender.tag].seourl
        print("self.seoUrlGetir :>",self.seoUrlGetir)
        performSegue(withIdentifier: "Posts", sender: self)
    }
    @objc func scrollBtnFollowersAction(sender: UIButton) {             //FOLLOWERS
        print("sender.tag :>",sender.tag)
        print("sendder[\(sender.tag)] :",categoryArray[sender.tag].name)
        self.categoryNameGetir = categoryArray[sender.tag].seourl
        print("self.categoryNameGetir :>",self.categoryNameGetir)
       
        performSegue(withIdentifier: "Follow", sender: self)
    }
    
    
    var syc:Int = 0
    @objc func scrollBtnFollowAction(sender: UIButton) {                    //FOLLOW
        // print("categoryArray[\(sender.tag)] :>",categoryArray[sender.tag].posts)
        if categoryArray[sender.tag].posts == "0" {
             sender.setTitle("FOLLOW", for: .normal)
            alertMesaj(title:"Follow Durumu",mesaj:"Bu kategoriye hiç posts yapılmmaış ki.. Takip edelim..")
             //print("Bu kategoriye hiç posts yapılmmaış ki.. Takip edelim..")
        }else{
        
            print("self.syc :>",self.syc)
             self.syc += 1
            if (self.syc % 2 ) == 1 {
                sender.setTitle("UNFOLLOW", for: .normal)
                for i in 0...(self.allPostDz.count-1){
                  
                    if categoryArray[sender.tag].name == allPostDz[i].category{
                        
                        print( "categoryid",allPostDz[i].categoryid)
                        followMeState.categoryFollowMe(authId: /*"EI-nUoWUuP"*/self.authIdAl, catid: "\(allPostDz[i].categoryid)", type: "follow")
                       // alertMesaj(title:"Follow Durumu",mesaj:self.followState/*"success follow"*/)
                        break
                    }
                }
            }else{
                sender.setTitle("FOLLOW", for: .normal)
                for i in 0...(self.allPostDz.count-1){
                    if categoryArray[sender.tag].name == allPostDz[i].category{
                        print( "categoryid",allPostDz[i].categoryid)
                        followMeState.categoryFollowMe(authId: /*"EI-nUoWUuP"*/self.authIdAl, catid: "\(allPostDz[i].categoryid)", type: "unfollow")
                         //alertMesaj(title:"Follow Durumu",mesaj:self.followState/*"success unfollow"*/)
                        break
                    }
                    
                }
          }
      }
   }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       if categoryArray.count > 0 {
         return categoryArray.count
       }else{
         return 0
       }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AllCategories", for: indexPath) as! AllCategory
        
        if categoryArray.count > 0 {
             cell.categoryName.text = self.categoryArray[indexPath.row ].name
            // Posts Buton kısmı
            cell.postsBtn.tag = indexPath.row
            cell.postsBtn.setTitle("\(categoryArray[indexPath.row ].posts) posts", for: .normal)
            cell.postsBtn.addTarget(self, action: #selector(self.scrollBtnPostAction), for: .touchUpInside)
            //Followers Buton Kısmı
            cell.takipcilerBtn.tag = indexPath.row
            cell.takipcilerBtn.setTitle("\(categoryArray[indexPath.row ].follower) followers", for: .normal)
            cell.takipcilerBtn.addTarget(self, action: #selector(self.scrollBtnFollowersAction), for: .touchUpInside)
            //Follow Buton Kısmı
            
            cell.followYapBtn.tag = indexPath.row
            cell.followYapBtn.setTitle("FOLLOW", for: .normal)
            cell.followYapBtn.backgroundColor = UIColor.lightGray
            cell.followYapBtn.layer.cornerRadius = 9
            //cell.followYapBtn.layer.borderColor = UIColor.red.cgColor
            cell.followYapBtn.addTarget(self, action: #selector(self.scrollBtnFollowAction), for: .touchUpInside)
 
            
        }
        else{
            alertMesaj(title: "Tüm Categoriler Kısmı, Bilgilendirme", mesaj: "Tüm Categoriler ile ilgili herhangi bir şey yok..")
        }
        return cell
        
    }
    func alertMesaj(title:String,mesaj:String){
        let alert = UIAlertController(title: title, message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
       /* if (segue.destination is CategoryFollowMeViewController){
            let categoriesController = segue.destination as! CategoryFollowMeViewController
            categoriesController.authID = /*"EI-nUoWUuP"*/self.authIdAl

        } */
        if (segue.destination is FollowersViewController){
            let followersController = segue.destination as! FollowersViewController
            followersController.categoryName = self.categoryNameGetir
        }else if (segue.destination is getPostsViewController){
            let getPostsController = segue.destination as! getPostsViewController
            getPostsController.seoUrlGetir = self.seoUrlGetir
        }
        else{
            print("error occured")
        }
        
    }
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }

    
}
