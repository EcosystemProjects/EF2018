//
//  getPostsViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 3.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class getPostsViewController:UIViewController,UITableViewDataSource,UITableViewDelegate,getPostsDataDelegate{
   
   
    @IBOutlet weak var tableview: UITableView!
    var postsDzAl :[getPostsData] = []
    var postsDataSource = getPostsDataSource()
    var seoUrlGetir :String = ""
    var imgDz = [UIImage(named: "oludeniz")]
    @IBOutlet weak var mScrollView: UIScrollView!
    let imgArray = [UIImage(named: "oludeniz")]
    @IBOutlet weak var getPostsNmae: UILabel!
    
    override func viewDidLoad() {
       
        self.getPostsNmae.text = "\(self.seoUrlGetir)"
        self.tableview.delegate = self
        self.tableview.dataSource = self
        
        //self.tableview.rowHeight = 300
        self.tableview.reloadData()
        
        postsDataSource.delegete=self
        super.viewDidLoad()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func getPostsDurum(getPostsDz: [getPostsData]) {
        self.postsDzAl=getPostsDz
        print("self.postsDzAl elemanı Tarih:>",self.postsDzAl[0].date)
         print("self.postsDzAl.count :>",self.postsDzAl.count)
       // setButtons()
        
       // self.tableview.estimatedRowHeight = 200
       // self.tableview.rowHeight = UITableViewAutomaticDimension
       
         DispatchQueue.main.async {
            
            self.tableview.reloadData()
        }
 
    }
  
    
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("self.seoUrlGetir :>",self.seoUrlGetir)
        postsDataSource.getDataPosts(seoUrl: self.seoUrlGetir)
        
       // self.tableview.estimatedRowHeight = 200
       // self.tableview.rowHeight = UITableViewAutomaticDimension
    }
    

    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        //self.postsDzAl.count
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.postsDzAl.count
        //return self.postsDzAl.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let getCell = tableView.dequeueReusableCell(withIdentifier: "getcell", for: indexPath) as! getPostsCell
        
        if postsDzAl.count > 0 {
            
       
            getCell.lblTitle.text! = postsDzAl[indexPath.row].region + "-" + postsDzAl[indexPath.row].ecosystem + "-" + postsDzAl[indexPath.row].category
            getCell.tarih.text! = postsDzAl[indexPath.row].date
            getCell.txtview.text = postsDzAl[indexPath.row].description
            getCell.imgResim.image = self.imgDz[0]
            //UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+postsDzAl[0].image))!))
        
            return getCell
            
        }else{
            
            getCell.lblTitle.text!  = "Değer gelmedi"
            return getCell
        }
    }
   // tableview deki her bir hücrenin genişliğini verir
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
 
   
}
