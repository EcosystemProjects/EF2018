//
//  PostViewDescription.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

// NOT : BU POSTDESCRİPTİON VIEW KISMINI KALDIRACAM

class PostViewDescription: UIViewController /*,DetayPostDelegate*/,PostsDataDelegate {
    
    let imgArray = [UIImage(named: "oludeniz")/*,UIImage(named: "oludeniz")*/]
    //let dataSource = DetayPostDataSource()
     let postdataSource = AllPostsDataSource()
    var postDetayArray :[EcosystemPostDecsription] = []
    var AllPostsArray : [EcoFeed] = []
    @IBOutlet weak var lblGelenVeri: UILabel!
    
    @IBOutlet weak var img2: UIImageView!
    var gelenVeriyiAl:String = ""
    var seoUrlAl:String = ""
    @IBOutlet weak var descriptionAlani: UITextView!
    @IBOutlet weak var regionGetir: UILabel!
    
    @IBOutlet weak var ecosystemGetir: UILabel!
    
    @IBOutlet weak var categoryGetir: UILabel!
    
    @IBOutlet weak var tarih: UILabel!
    
    
    var indexNoAl:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //dataSource.delegate =  self
        postdataSource.delegate = self
        if (gelenVeriyiAl == ""){
            print("Herhangi bir değer yok")
        }else{
            lblGelenVeri.text = gelenVeriyiAl
            print("gelenVeriyiAl :>",gelenVeriyiAl)
            print("indexNoAl :>",indexNoAl)
             print("seoUrlAl :>",seoUrlAl)
            print("lblGelenVeri.text ",lblGelenVeri.text!)
        }
      
    }
    /*
    func detayPostListLoaded(PostDetayList: [EcosystemPostDecsription]) {
        self.postDetayArray = PostDetayList
        print("self.postDetayArray.count :>",self.postDetayArray.count)
        DispatchQueue.main.async {
            self.verileriGoster()
        }
        
    }
 */
    override func viewWillAppear(_ animated: Bool) {
       // dataSource.detayPostList(detayPostName: self.seoUrlAl)
        postdataSource.loadAllPostsList()
    }
    func tumPostlar(getAllPostsList : [EcoFeed]) {
        self.AllPostsArray = getAllPostsList
        // print("self.AllPostsArray: ",self.AllPostsArray)
        DispatchQueue.main.async {
            self.verileriGoster()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    func verileriGoster(){
       
        if self.AllPostsArray.count > 0 {
            
            if self.gelenVeriyiAl == self.AllPostsArray[self.indexNoAl].title {
                
                let parseYap = self.AllPostsArray[self.indexNoAl].image.components(separatedBy: "/")
                print("parseYap :>",parseYap)
                if parseYap[4] != "" {
                    self.regionGetir.text! = AllPostsArray[self.indexNoAl].region
                    self.ecosystemGetir.text! = AllPostsArray[self.indexNoAl].ecosystem
                    self.categoryGetir.text! = AllPostsArray[self.indexNoAl].category
                    self.tarih.text! = AllPostsArray[self.indexNoAl].date
                    self.descriptionAlani.text! = AllPostsArray[self.indexNoAl].description
                    self.img2.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+AllPostsArray[self.indexNoAl].image))!))
                }
                else{
                    self.regionGetir.text! = AllPostsArray[self.indexNoAl].region
                    //self.img2.image = self.imgArray[0]
                    self.ecosystemGetir.text! = AllPostsArray[self.indexNoAl].ecosystem
                    self.categoryGetir.text! = AllPostsArray[self.indexNoAl].category
                    self.tarih.text! = AllPostsArray[self.indexNoAl].date
                    self.descriptionAlani.text! = AllPostsArray[self.indexNoAl].description
                    
                }
            }
      
        
        
        }else {
           
            alertMesaj(mesaj:"Bu Category'e ait detay bulunamamıştır..")
        }
          
    }
    func alertMesaj(mesaj:String){
        let alert = UIAlertController(title: "Post Detay Durumu", message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func quit(_ sender: Any) {
        dismissThisController()
    }
    func dismissThisController()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.dismiss(animated: true, completion: {})
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
