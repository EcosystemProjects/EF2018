//
//  PostViewDescription.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

// NOT : BU POSTDESCRİPTİON VIEW KISMINI KALDIRACAM

class PostViewDescription: UIViewController /*,DetayPostDelegate*/{

    let imgArray = [UIImage(named: "oludeniz")/*,UIImage(named: "oludeniz")*/]
    let dataSource = DetayPostDataSource()
    var postDetayArray :[EcosystemPostDecsription] = []
 
    @IBOutlet weak var lblGelenVeri: UILabel!
    
    @IBOutlet weak var img2: UIImageView!
    var gelenVeriyiAl:String!
   
    @IBOutlet weak var DescriptionTextView: UILabel!
    
    @IBOutlet weak var regionGetir: UILabel!
    
    @IBOutlet weak var ecosystemGetir: UILabel!
    
    @IBOutlet weak var categoryGetir: UILabel!
    
    @IBOutlet weak var tarih: UILabel!
    
    
    var sayac:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // dataSource.delegate =  self
        // Do any additional setup after loading the view.
        
        if gelenVeriyiAl == nil{
            print("Herhangi bir değer yok")
        }else{
            lblGelenVeri.text = gelenVeriyiAl
            print("lblGelenVeri.text ",lblGelenVeri.text!)
        }
       // getAllPost()
       
        
    }
   /* func detayPostListLoaded(PostDetayList: [EcosystemPostDecsription]) {
        self.postDetayArray = PostDetayList
        print("self.postDetayArray :>",self.postDetayArray)
        verileriGoster()
    }
    override func viewWillAppear(_ animated: Bool) {
        dataSource.detayPostList(detayPostName: self.gelenVeriyiAl)
        
        
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   */
    func verileriGoster(){
        
       // while self.sayac < postDetayArray.count{
            
            if self.lblGelenVeri.text == postDetayArray[self.sayac].title {
                
                self.regionGetir.text! = postDetayArray[self.sayac].region
                self.ecosystemGetir.text! = postDetayArray[self.sayac].ecosystem
                self.categoryGetir.text! = postDetayArray[self.sayac].category
                self.tarih.text! = postDetayArray[self.sayac].date
                self.DescriptionTextView.text! = postDetayArray[self.sayac].description
                self.img2.image = self.imgArray[0]
                // = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+json[0].image))!)) // 1. indexte sunucudan hata alınıyor beratın düzeltmesi lazım Resim doğru formatta değil
                
                
            }
            
            print("sayac ->", self.sayac)
            self.sayac += 1
         //   break
        //}
    }
    
    
    func getAllPost() {
        
        var request = URLRequest(url: URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=")!)//kategroi ismi gelicek
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let urlSession = URLSession.shared
        urlSession.dataTask(with: request) { (data, response, error) in
            /* if let response = response{
             print(response)
             }
             */
            guard let data = data else {return}
            //print("data", data)
          
            do{
                let json = try JSONDecoder().decode([EcosystemPostDecsription].self,from: data)
               
                while self.sayac < json.count{
                    
                    if self.lblGelenVeri.text == json[self.sayac].title{
                        
                        self.regionGetir.text! = json[self.sayac].region
                        self.ecosystemGetir.text! = json[self.sayac].ecosystem
                        self.categoryGetir.text! = json[self.sayac].category
                        self.tarih.text! = json[self.sayac].date
                        self.DescriptionTextView.text! = json[self.sayac].description
                        self.img2.image = self.imgArray[0]
                                        // = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+json[0].image))!)) // 1. indexte sunucudan hata alınıyor beratın düzeltmesi lazım Resim doğru formatta değil
                        
                        
                    }
                     print("sayac ->", self.sayac)
                     self.sayac += 1
                }
                
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
