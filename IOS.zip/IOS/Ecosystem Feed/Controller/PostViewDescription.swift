//
//  PostViewDescription.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

struct EcosystemPostDecsription:Decodable{
    let title:String
    let description:String
    let image:String
    let date:String
    let category:String
    let ecosystem:String
    let region:String
    let shareurl:String
}

class PostViewDescription: UIViewController {

    let imgArray = [UIImage(named: "oludeniz")/*,UIImage(named: "oludeniz")*/]
 
    @IBOutlet weak var lblGelenVeri: UILabel!
    var gelenVeriyiAl:String!
    
    @IBOutlet weak var img: UIImageView!
    //@IBOutlet weak var DescriptionTextView: UITextField!
    @IBOutlet weak var DescriptionTextView: UILabel!
    
    
    @IBOutlet weak var regionGetir: UILabel!
    @IBOutlet weak var ecosystemGetir: UILabel!
    @IBOutlet weak var categoryGetir: UILabel!
    @IBOutlet weak var tarih: UILabel!
    
 
    
    var sayac:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if gelenVeriyiAl == nil{
            print("Herhangi bir değer yok")
        }else{
            lblGelenVeri.text = gelenVeriyiAl
            print("lblGelenVeri.text ",lblGelenVeri.text!)
        }
        getAllPost()
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getAllPost() {
        
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=Mugla")
        let urlSession = URLSession.shared
    
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             print(response)
             }
             */
            guard let data = data else {return}
            //print("data", data)
          
            do{
                let json = try JSONDecoder().decode([EcosystemPostDecsription].self,from: data)
               
                while self.sayac < json.count{
                    
                    if self.lblGelenVeri.text == json[self.sayac].title{
                        
                        self.regionGetir.text! = json[self.sayac].region
                        self.ecosystemGetir.text! = json[self.sayac].ecosystem
                        self.categoryGetir.text! = json[self.sayac].category
                        self.tarih.text! = json[self.sayac].date
                        self.DescriptionTextView.text! = json[self.sayac].description
                        self.img.image = self.imgArray[0]
                    }
                     print("sayac ->", self.sayac)
                     self.sayac += 1
                }
                
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
