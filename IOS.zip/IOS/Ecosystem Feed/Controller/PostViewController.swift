//
//  fouthViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 19.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
//import  Foundation
import Alamofire

struct PostState:Codable{
    let function:String
    let status:String
    
    private enum CodingKeys:String,CodingKey{
        case function = "Function", status = "status"
        
    }
}
class PostViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPickerViewDelegate,UIPickerViewDataSource, URLSessionDelegate, URLSessionTaskDelegate, URLSessionDataDelegate,RegionDataDelegate, CategoryDataDelegate, EcosystemDataDelegate ,PostsDataDelegate{
    @IBOutlet weak var link: UITextView!
    
    @IBOutlet weak var edit: UIButton!
    
    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var postImageAdiniGri: UITextView!
    @IBOutlet weak var postButton: UIButton!
    
    @IBOutlet weak var titleF: UITextView!
    @IBOutlet weak var descF: UITextView!
    
    @IBOutlet weak var pick1: UIPickerView!
    @IBOutlet weak var pick2: UIPickerView!
    @IBOutlet weak var pick3: UIPickerView!
    @IBOutlet weak var pick4: UIPickerView!
    
    @IBOutlet weak var viewI: UIView!
    
   
    let dataSource = RegionDataSource()
    var regionArray : [Region] = []
    let myPostErisim = MyPostDataSource()
    
    let dataSource2 = EcosystemDataSource()
    var ecosystemArray : [Ecosystem] = []
    
    let dataSource3 = CategoryDataSource()
    var categoryArray : [Category] = []
    
    let dataSource5 = AllPostsDataSource()
    var AllPostsArray : [EcoFeed] = []
    
    var selectedRegion : Region?
    var selectedEcosystem : Ecosystem?
    var selectedCategory : Category?
    var selectedCategoryName:String = ""
    var authID:String = ""
    //var dataSource4 = CreateNewPostDataSource()
    let pickerController = UIImagePickerController()
   
    var getCategoryArray :[[String:Any]] = [[:]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        let keyboardRecognizer = UITapGestureRecognizer(target: self, action: #selector(PostViewController.hideKeyboard))
        self.view.addGestureRecognizer(keyboardRecognizer)

        postImage.isUserInteractionEnabled = true
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(PostViewController.choosePhoto))
        postImage.addGestureRecognizer(gestureRecognizer)
        
        self.link.layer.shadowRadius = 9
        self.link.layer.cornerRadius = 9
        self.link.layer.masksToBounds = false
        self.link.layer.shadowOpacity = 0.3
        self.titleF.layer.cornerRadius = 9
        self.descF.layer.cornerRadius = 9
        self.viewI.layer.cornerRadius = 9
        
        pick1.delegate = self
        pick1.dataSource = self
        
        pick2.delegate = self
        pick2.dataSource = self
        
        pick3.delegate = self
        pick3.dataSource = self
        
        pick4.delegate = self
        pick4.dataSource = self
        
        pick1.tag = 1
        pick2.tag = 2
        pick3.tag = 3
        pick4.tag = 4
        
        self.dataSource.delegate = self
        self.dataSource2.delegate = self
        self.dataSource3.delegate = self
        self.dataSource5.delegate = self
        pickerController.delegate = self
  
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if CheckInternet.Connection(){
           // alertMesaj(title: "Internet Connection ", mesaj: "İnternet Connection")
            dataSource.loadRegionList()
            dataSource5.loadAllPostsList()
            let tabbar = tabBarController as! CustomTabBar
            self.authID = tabbar.authID
            print("self.authID :>",self.authID)
           // print("tabbar.shareURL POST:>",tabbar.shareURL)
            
        }
        else{
            alertMesaj(title: "Internet Connection ", mesaj: "İnternetiniz yok, veya internete bağli değilsiniz.. .İşlem yapabilmek için internete bağlanmalısınız..")
        }
       
    }
    func tumPostlar(getAllPostsList : [EcoFeed]) {
        self.AllPostsArray = getAllPostsList
        // print("self.AllPostsArray: ",self.AllPostsArray)
        DispatchQueue.main.async {
            self.pick4.reloadAllComponents()
        }
        print("AllPostsArray  Count:")
        print(AllPostsArray.count)
    }
    
    func regionListLoaded(regionList: [Region]) {
        self.regionArray = regionList
            DispatchQueue.main.async {
                self.pick1.reloadAllComponents()
            }
    }
    
    func ecosystemListLoaded(ecosystemList: [Ecosystem]) {
        self.ecosystemArray = ecosystemList
        DispatchQueue.main.async {
            self.pick2.reloadAllComponents()
        }
        print("Ecosystem Array Count:")
        print(ecosystemList.count)
    }
    func getCategoriesList(getcategoryList: [[String:Any]]) {
        self.getCategoryArray = getcategoryList
        print("self.getCategoryArray :>",self.getCategoryArray)
    }
    func categoryListLoaded(categoryList: [Category]) {
        self.categoryArray = categoryList
     
        DispatchQueue.main.async {
            self.pick3.reloadAllComponents()
        }
        print("Category Array Count:")
        print(categoryList.count)

        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView.tag == 1){
            if regionArray.count != 0{
                return regionArray.count
            }else{
                return 0
            }
            
        }
        else if(pickerView.tag == 2){
            if ecosystemArray.count != 0{
                return ecosystemArray.count
            }else{
                return 0
            }
            
        }
        else if(pickerView.tag == 3){
            if categoryArray.count != 0{
                return categoryArray.count
            }else{
                return 0
            }
            
        }else{
            if AllPostsArray.count != 0{
                 return AllPostsArray.count
            }else{
                return 0
            }
           
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView.tag == 1){
            
            if regionArray[row].name.isEmpty{
                return regionArray[row].name
            }else{
                return regionArray[row].name
            }
            
            
        }
        else if(pickerView.tag == 2){
            if ecosystemArray[row].name.isEmpty{
                return ecosystemArray[row].name
            }else{
                return ecosystemArray[row].name
            }
            
        }
        else if(pickerView.tag == 3){
            if categoryArray[row].name.isEmpty{
                 return categoryArray[row].name
            }else{
                 return categoryArray[row].name
            }
        }
        else{
            if AllPostsArray[row].shareurl.isEmpty{
                return AllPostsArray[row].shareurl
            }else{
                return AllPostsArray[row].shareurl
            }
        }
    }
    var linkString:String = ""
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView.tag == 1){
            self.selectedRegion = regionArray[row]
            dataSource2.loadEcosystemList(groupid: (selectedRegion?.id)!)
            ecosystemListLoaded(ecosystemList: ecosystemArray)
            
        }
        else if(pickerView.tag == 2){
            self.selectedEcosystem = ecosystemArray[row]
            dataSource3.loadCategoryList(groupid: (selectedEcosystem?.id)!)
            categoryListLoaded(categoryList: categoryArray)

        }
         else if(pickerView.tag == 3){
            self.selectedCategory = categoryArray[row]
            self.selectedCategoryName = categoryArray[row].name
        }else{
            self.dataSource5.loadAllPostsList()
            self.linkString = AllPostsArray[row].shareurl
           
        }
        
    }
 
    @IBAction func uploadButton(_ sender: Any) {
        choosePhoto()
    }
    
    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
    
    @objc func choosePhoto() {
        
        pickerController.allowsEditing = true
        pickerController.sourceType = .photoLibrary
       self.present(pickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let editImage = info[UIImagePickerControllerEditedImage] as? UIImage{
            postImage.image = editImage
           
            let dataImage = UIImageJPEGRepresentation(self.postImage.image!, 0.6)
            print("dataImage1 ",dataImage!)
        } else if let originalImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            postImage.image = originalImage
             let dataImage = UIImageJPEGRepresentation(self.postImage.image!, 0.6)
            print("dataImage2 ",dataImage!)
        }
        
        
        self.dismiss(animated: true, completion: nil)
    }
   
    @IBAction func importBtn(_ sender: Any) {
         self.link.text! = self.linkString
        if self.link.text! != "" {
            self.link.text! = self.linkString
            otomatikDoldur()
        }else{
            alertMesaj(title: "Otomatik Doldurma Durumu", mesaj: "Picker da olan URL lerden birini seçiniz..")
        }
    }
    func otomatikDoldur(){
        //print("otomatikDoldur()")
         DispatchQueue.main.async {
            for i in 0...self.AllPostsArray.count{
                if self.linkString == self.AllPostsArray[i].shareurl{
                    self.titleF.text! = self.AllPostsArray[i].title
                    self.descF.text! = self.AllPostsArray[i].description
                    
                    let parseYap = self.AllPostsArray[i].image.components(separatedBy: "/")
                    if parseYap[4] != "" {
                        self.postImage.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+self.AllPostsArray[i].image))!))
                    }
                    else{
                            self.postImage.image = nil
  
                    }
                    break
               }
                
            }
    }
        
    }
    @IBAction func createPostSend(_ sender: Any) {
        
       // if self.link.text! == ""{
          if (titleF.text! == "") ||  (self.selectedCategoryName == "") || ((descF.text!) == "")  {
                self.alertMesaj(title:"Follow Durumu",mesaj:"Boş Alan Bırakmayınız..")
            }else{
            self.alertMesaj(title:"Post OLuşturma Durumu",mesaj:"Bu işlem biraz zaman alabilir.Lütfen Bekleyiniz. Post oluşturma ile ilgili olup olmadığına dair bir alert mesaj")
                myImageUploadRequest()
               // alamofireUploadMostParametersAndImage()
            }
        /*}else{
            otomatikDoldur()
        }*/
    }
    
    @IBAction func showMyPostBtn(_ sender: Any) {
        let tabbar = tabBarController as! CustomTabBar
        self.authID = tabbar.authID
        //print("self.selectedCategoryName :>",self.selectedCategoryName)
        performSegue(withIdentifier: "mypostlarim", sender: nil)
    }
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is MyPostDeneme){
            let mPostController = segue.destination as! MyPostDeneme
            mPostController.authIDGetir = /*"EI-nUoWUuP"*/self.authID
            mPostController.categoryAdi =  self.selectedCategoryName
            
        }
    }

    func myImageUploadRequest()
    {
       // print("self.authID  func ta:>",self.authID)
        if(postImage.image != nil)  {
            
            postGonderme()
        }
        else{
                print("Resim girmediniz..");
                alertMesaj(title: "Resim Seçme Durumu", mesaj: "Resim Seçmediniz....")
                DispatchQueue.main.async {
                    self.postImage.image = UIImage(named: "soruIsareti")//nil
                    
                }
                //postGonderme()
            }
        
    }
    
    func postGonderme(){
        
        let myUrl = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=setPosts");
        
        let request = NSMutableURLRequest(url:myUrl!);
        request.httpMethod = "POST"
        
        let imageData = UIImageJPEGRepresentation(postImage.image!, 0.9)
        let base64ConvertImageData = imageData?.base64EncodedData()
        print("base64ConvertImageData :>",base64ConvertImageData!)
        //print("self.authID  postGonderme de:>",self.authID)
        let param = [
            "authid"  : "\(self.authID)",//"EI-nUoWUuP",
            "title"    : "\(titleF.text!)",
            "description"  : "\(descF.text!)",
            "seourl"         : "\(self.selectedCategoryName)"
        ]
        let boundary =  generateBoundaryString()
        print("boundary :>",boundary)
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = createBodyWithParameters(parameters: param, filePathKey: "image", imageDataKey: base64ConvertImageData! as NSData, boundary: boundary) as Data
        
        
        let session = URLSession.shared
        
        //let task = session.dataTask(with: request) { (data, response, error) in
        let task = session.dataTask(with: request as URLRequest) {
            data, response, error in
            if error != nil {
                print("error=\(error!)")
                return
            }
            
            // You can print out response object
            print("******* response = \(response!)")
            
            // Print out reponse body
            if let jsonData = data {
                let dataAsString = String(data: jsonData,encoding:.utf8)
                
                print("jsonData :>",dataAsString!)
                
            }
            let decoder = JSONDecoder()
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                
                let postDurum = try decoder.decode(PostState.self, from: data!)
                
                self.alertMesaj(title:"Post OLuşturma Durumu",mesaj:postDurum.status) //alert durum
                print(json)
                
                DispatchQueue.main.async {
                    self.postImage.image = nil;
                    
                }
            }catch
            {
                print("error :>",error)
            }
            
        }
        
        task.resume()
    }
    
    
//alert mesaj
    func alertMesaj(title:String,mesaj:String){
        let alert = UIAlertController(title: title, message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Tamam", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
        
        
    let body =  NSMutableData()
    func createBodyWithParameters(parameters: [String: String]?, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
         let body =  NSMutableData()
        
        if parameters != nil {
            for (key, value) in parameters! {
               
              //  if key == "image" {
                   // print("key(title) :>",key)
                 // resimEkle(filePathKey:filePathKey,imageDataKey:imageDataKey)
                //}else{
                    body.appendString(string: "--\(boundary)\r\n")
                    body.appendString(string:"Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                    body.appendString(string:"\(value)\r\n")
                    
              //  }
                
            }
            print("parameters :> ",parameters!)
        }
        
        let filename = /*"image"*/"user-profile.jpg"
        let mimetype = "image/jpeg"
        
        body.appendString(string:"--\(boundary)\r\n")
        body.appendString(string:"Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString(string:"Content-Type: \(mimetype)\r\n\r\n")
        
        body.append(imageDataKey as Data) // resim kısmı ,bu kısmı iyi düşünülmeli
        body.appendString(string:"\(imageDataKey)\r\n")
        //body.appendString(string:"\r\n")
        
        
        body.appendString(string:"--\(boundary)--\r\n")
 
        
        return body
    }
   /*
    func resimEkle(filePathKey:String?,imageDataKey: NSData){
        
       // let boundary = generateBoundaryString()
        
        let filename = "user-profile.jpg"
        let mimetype = "image/jpg"
        
        body.appendString(string:"--\(boundary)\r\n")
        body.appendString(string:"Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString(string:"Content-Type: \(mimetype)\r\n\r\n")
        
        body.append(imageDataKey as Data) // resim kısmı ,bu kısmı iyi düşünülmeli
        body.appendString(string:"\(imageDataKey)\r\n")
        //body.appendString(string:"\r\n")
        
        
        body.appendString(string:"--\(boundary)--\r\n")
    }
    */
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    
}
extension NSMutableData {
   // let dataAsString = String(data: jsonData,encoding:.utf8)
    func appendString(string: String) {
        
       let data = string.data(using : .utf8)
        // = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        append(data!)
    }
}
    



















