//
//  Deneme.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class MyPostDeneme: UIViewController , UITableViewDelegate,UITableViewDataSource,MyPostDataDelegate,DeletePost{
    
    var getAuthId: String = ""
   let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]

    
    var dataSource = MyPostDataSource()
    @IBOutlet weak var tableView: UITableView!
    let welcomeControl = welcomeViewController()
    var deleteSource = DeletePostDataSoUrce()
    var myPostsArray:[myPosts] = []
    var categoryAdi:String = ""
    var authIDGetir:String = ""
    var seoURLGetir:String = ""
    var categoryDizi:[String] = []
    var durum:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource.delegate = self
        deleteSource.delegate = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
  
    }
    func myPostsListLoaded(mPostsList: [myPosts]) {
        self.myPostsArray=mPostsList
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
    }
    func deleteStatus(durum: String) {
        self.durum = durum
        alertMesaj(mesaj:self.durum)
        
    }
    override func viewWillAppear(_ animated: Bool) {
    
        print("MyPostDeneme da authID :>",authIDGetir,"MyPostDeneme da categoryadi :>",categoryAdi)
        
        if (authIDGetir != "") {            
            print("authIDGetir :>",authIDGetir )
        }else{
            print(" Boş authID")
        }
        dataSource.myPostsList(authID: authIDGetir)
        //deleteSource.deletePost(authID: authIDGetir, seoUrl: categoryAdi)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myPostsArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell =  tableView.dequeueReusableCell(withIdentifier: "MyPostsCell", for: indexPath) as!  MyPostsCell
        
        
        if myPostsArray.count > 0{
            
            cell.img.tag = indexPath.row
            let categoryAd = self.myPostsArray[indexPath.row % myPostsArray.count]
            let parseYap = self.myPostsArray[indexPath.row ].image.components(separatedBy: "/")
            
            print("parseYap :>",parseYap[4]/*,"--",parseYap[4]*/)
            if parseYap[4] != "" {
                
                cell.categoryInformation.text! = myPostsArray[indexPath.row].region + "-"+myPostsArray[indexPath.row].ecosystem+"-"+myPostsArray[indexPath.row].category+"\n"+myPostsArray[indexPath.row].title
                cell.date.text! = myPostsArray[indexPath.row].date
                cell.desc.text! = myPostsArray[indexPath.row].description
                cell.img.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+myPostsArray[indexPath.row].image))!))
                
                categoryDizi.append(categoryAd.seourl)
                
            }else{
                
                cell.categoryInformation.text! = myPostsArray[indexPath.row].region + "-"+myPostsArray[indexPath.row].ecosystem+"-"+myPostsArray[indexPath.row].category+"\n"+myPostsArray[indexPath.row].title
                cell.date.text! = myPostsArray[indexPath.row].date
                cell.desc.text! = myPostsArray[indexPath.row].description //hata oluvcak mı..
                cell.img.isHidden = true
                //cell.img.frame = CGRect(x:  Int(indexPath.row)-(Int(self.tableView.contentSize.width-20)/2), y:30, width: Int(self.tableView.contentSize.width-90), height: 0)
                // boyut kısımlarını sonraya doğru yapmaya çalışırız
                
                categoryDizi.append(categoryAd.seourl)
            }
            
            
            return cell
        }
        else{
            alertMesaj(mesaj:"Sunucu yavaş çalışıyor olabilir veya herhangi bir post göndermemişsiniz..")
            return cell
        }
    }
    
    func alertMesaj(mesaj:String){
        let alert = UIAlertController(title: "My Posts State", message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    var sayac:Int = 0
    
    @IBAction func deletePosstMe(_ sender: Any) {
        print("self.categoryDizi[\(self.sayac)] :>" ,self.categoryDizi[self.sayac])
        deleteSource.deletePost(authID: self.authIDGetir, seoUrl: self.categoryDizi[self.sayac])
        
    }
    
    @IBAction func followMe(_ sender: Any) {
        print("tıklandı..")
        performSegue(withIdentifier: "categoryFollowMe", sender: nil)
    }
    /*
    @IBAction func createdShow(_ sender: Any) {
        performSegue(withIdentifier: "creatShow", sender: nil)
    }
 */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is PostViewController){
            let postController = segue.destination as! PostViewController
            postController.authID = self.authIDGetir
        }else if (segue.destination is CategoryFollowMeViewController){
            let categoriesController = segue.destination as! CategoryFollowMeViewController
            categoriesController.authID = self.authIDGetir
        }
        else{
            print("error occured")
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
