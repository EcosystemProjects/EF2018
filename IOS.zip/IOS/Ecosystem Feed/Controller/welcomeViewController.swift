//
//  welcomeViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 20.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import Foundation
import  Alamofire

class welcomeViewController:  UIViewController ,UserDataDelegate{
    
    var getAuthId: String = ""
    @IBOutlet weak var getStarted: UIButton!
    @IBOutlet var linkedinProfileImg:UIImageView!
    var user = UserDataSource()
    var notiBildirim = NotificationDataSource()
    var authID:String = ""
    var userID:String = ""
    var firstName:String = ""
    var lastName:String = ""
    var emailAddress:String = ""
    var publicProfileUrl:String  = ""
    
    override func viewDidLoad() {
        
       user.delegate = self
        getStarted.layer.cornerRadius = 10
    
        super.viewDidLoad()

    }


    override func viewWillAppear(_ animated: Bool) {
        print("welcomeViewController dayız :)")
   
        /*if let publicProfileUrl != ""{
         linkedinProfileImg.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: (self.publicProfileUrl))!))
         }
         */
        
        // kullanıcıyı burdan kaydetme,deneme amaçlı olarak kalsın suanlık
        self.user.userBilgileri(authId: "S7UA261fjN" , firstName: "mansur emin" , lastName: "kaya" , emailAddress: "kayamansur61@gmail.com" , publicProfileUrl: "https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM")
        
        //bu kısıma veriler viewControllerdan geliyor..
    print("authID  :>",self.authID ,"-","userID :>",self.userID,"-","fisrtName :>",self.firstName,"-","lastName :>",self.lastName,"-","emailAddress :>",self.emailAddress,"-","publicProfileUrl :>",self.publicProfileUrl)
        
    }
    
    func getUserMesaj(mesaj: String, sessionID: String) {
        
        if (mesaj == "success login" ) || (sessionID != "") {
            print("mesaj :>",mesaj)
            print("sessionID :>",sessionID)
            alertMesaj(mesaj:mesaj)
        }
        else{
            
            print("Böyle bir kullanıcı yok")
            
        }
    }
    func alertMesaj(mesaj:String){
        let alert = UIAlertController(title: "Linkedin ile Üyelik Durumu", message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    @IBAction func logOut(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "user")
        UserDefaults.standard.synchronize()
        
        let SignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUp") as? ViewController
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = SignUp
        delegate.rememberLogin()
    }
   
    @IBAction func getStart(_ sender: Any) {
        
       performSegue(withIdentifier: "basla", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is CustomTabBar){
            let custumBar = segue.destination as! CustomTabBar
            custumBar.authID = "EI-nUoWUuP"
            custumBar.profilGonder = "profil" //self.publicProfileUrl
            custumBar.mailAdres = "mailadres"//self.emailAddress
        }
        else{
            print("error occured")
        }
        
    }
    
    
    
}
