//
//  welcomeViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 20.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class welcomeViewController: UIViewController {

   
    @IBOutlet weak var getStarted: UIButton!
    
    var user = UserDataSource()
    var notiBildirim = NotificationDataSource()
    var authID:String = ""
    var userID:String = ""
    //let ad:String = "mansur emin"
    //let AuthIDAl:String? = nil
    override func viewDidLoad() {
       
        //print("\"firstName\"" + ":" + "\"\(self.ad)\"")
        //let string = "http://ecosystemfeed.com/Service/Web.php?process=isLogin&json={"+"\"json\""+":{" + "\"emailAddress\":"+"\"kayamansur61@gmail.com\"," + "\"firstName\":"+"\"mansur emin\"," + "\"lastName\":"+"\"kaya\"," + "\"publicProfileUrl\":"+"\"https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM\"," + "\"authId\":"+"\"S7UA261fjN\""+"}}"
        //print("stringURL :> ",string)
        
        self.user.userBilgileri(authId: "S7UA261fjN" , firstName: "mansur emin" , lastName: "kaya" , emailAddress: "kayamansur61@gmail.com" , publicProfileUrl: "https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM" )
        getStarted.layer.cornerRadius = 10
        
        //self.notiBildirim.notificaitonList(authID: self.authID, userID: self.userID)
       // print("viewDidload ta :",self.getAuthID())
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool) {
        print("authID  :>",self.authID ,"-","userID :>",self.userID)
     //    print("viewWillAppear da :",self.getAuthID())
    }
    @IBAction func logOut(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "user")
        UserDefaults.standard.synchronize()
        
        let SignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUp") as? ViewController
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = SignUp
        delegate.rememberLogin()
    }
    /*
    func getAuthID()->String{
    
        return self.AuthIDAl!
    }
    */
    @IBAction func getStart(_ sender: Any) {
        
       // performSegue(withIdentifier: "basla", sender: nil)
        
    }
    
    
}
