//
//  CustomTabBar.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 19.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class CustomTabBar:UITabBarController{
    
    var authID:String = ""
    var profilGonder:String  = ""
    var mailAdres:String = ""
     var shareURL:String = ""
    var tabBarIteam = UITabBarItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("authID , CustomTabBar da:>:>:>",authID)
      
    }
    override func viewWillAppear(_ animated: Bool) {
        print("authID , CustomTabBar da:>:>:>",authID,"custunBar da profilGonder :>",profilGonder)
        
    }
  
}
