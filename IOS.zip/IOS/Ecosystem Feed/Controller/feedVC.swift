//
//  feedVC.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 17.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit


class feedVC: UIViewController, UITableViewDelegate, UITableViewDataSource ,PostsDataDelegate  {
  
    @IBOutlet weak var tableView: UITableView!
    var activityIndicator:UIActivityIndicatorView =  UIActivityIndicatorView()
    let dataSource = AllPostsDataSource()
    var AllPostsArray : [EcoFeed] = []
   
   
     let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]
    var dz = [String]()  // boş dizi
    var degerAl:String!
    var sayac:Int = 0 ,sayac2 = 0 ,sayac3 = 0
    //var degerAlata:String!
    var servisUzunluk:Int!
    var indexAl:Int = 0
    var veriYolla :String = ""
    var seoUrlYolla :String = ""
    var indexYolla:Int = 0
    //http://ecosystemfeed.com/assets/img/posts/oludeniz.jpg
   // var nameArray = ["oludeniz","oludeniz2"]
    
    
    var fedCellEkleme = feedCell()
    
    override func viewDidLoad() {
        
        let keyboardRecognizer = UITapGestureRecognizer(target: self, action:#selector(feedVC.hideKeyboard))
       self.dataSource.delegate = self
        self.view.addGestureRecognizer(keyboardRecognizer)
        tableView.delegate = self
        tableView.dataSource = self
     
       // getAllPostVeriDondur()
        
        super.viewDidLoad()
    }
  
    func tumPostlar(getAllPostsList : [EcoFeed]) {
        self.AllPostsArray = getAllPostsList
       // print("self.AllPostsArray: ",self.AllPostsArray)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    
    }
    override func viewWillAppear(_ animated: Bool) {
       // print("self.veriYolla gelmiş mi",self.veriYolla ,"self.AllPostsArray: ",self.AllPostsArray)
       //dataSource.loadAllPostsList()
        if CheckInternet.Connection(){
            dataSource.loadAllPostsList()
            
            //alertMesaj(title: "Internet Connection ", mesaj: "İnternet Connection")
        }
        else{
            alertMesaj(title: "Internet Connection ", mesaj: "İnternetiniz yok, veya internete bağli değilsiniz.. .İşlem yapabilmek için internete bağlanmalısınız..")
        }
        
        
    }
    /*
    override func viewDidAppear(_ animated: Bool) {
        if CheckInternet.Connection(){
            // dataSource.loadAllPostsList()
            alertMesaj(title: "Internet Connection ", mesaj: "Connection")
        }
        else{
            alertMesaj(title: "Internet Connection ", mesaj: "İnternetiniz yok, veya internete bağli değilsiniz.. .İşlem yapabilmek için internete bağlanmalısınız..")
        }
        
    }
 */
    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if self.AllPostsArray.count > 0{
           
            activityIndicator.stopAnimating()
            return self.AllPostsArray.count
        }
        else{
            
            
            self.activityIndicator.center = self.view.center
            self.activityIndicator.hidesWhenStopped = true
            self.activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
            self.view.addSubview(self.activityIndicator)
            self.activityIndicator.sizeThatFits(CGSize(width: 200.0, height: self.activityIndicator.frame.size.height))
            
            self.activityIndicator.startAnimating()
           
            return 0
        }
       
        
    }
    
    func alertMesaj(title:String,mesaj:String){
        let alert = UIAlertController(title: title, message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 410
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! feedCell
       
       
        if 0 < AllPostsArray.count{
            /*
            let tabbar = tabBarController as! CustomTabBar
            tabbar.shareURL = AllPostsArray[indexPath.row].shareurl
 
            print("tabbar.shareURL :>",tabbar.shareURL)
  */
            let parseYap = self.AllPostsArray[indexPath.row ].image.components(separatedBy: "/")
           
            //print("parseYap :>",parseYap,"-->",parseYap[4])
            
            if parseYap[4] != "" {
                
                cell.btnLearn.tag = indexPath.row
                cell.userNameLabel.text = self.AllPostsArray[indexPath.row ].title
                cell.postImage.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+self.AllPostsArray[indexPath.row].image))!))
                
                cell.LabelTexrAlani.text = self.AllPostsArray[indexPath.row ].description
                cell.btnLearn.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
                
            }else{
                
                cell.btnLearn.tag = indexPath.row
                cell.userNameLabel.text = self.AllPostsArray[indexPath.row ].title
                cell.postImage.isHidden = true
                cell.LabelTexrAlani.text = self.AllPostsArray[indexPath.row ].description
                cell.btnLearn.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
            }
            
           
        }
        else{
           alertMesaj(title: "Yükleniyor..", mesaj: "Sunucudan, uygulamaya veriler yüklenirken yavaş olabilir.. (Bu işlem yavaş olabilir..)")
        }
        
        return cell
 
    }
    
    @objc func scrollButtonAction(sender: UIButton) {
        print("sender.tag :>",sender.tag)
        self.veriYolla = AllPostsArray[sender.tag].title
        self.seoUrlYolla = AllPostsArray[sender.tag].category
        self.indexYolla = sender.tag
        performSegue(withIdentifier: "postDetay", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is PostViewDescription){
            let getpostDetay = segue.destination as! PostViewDescription
           getpostDetay.gelenVeriyiAl = self.veriYolla
             getpostDetay.seoUrlAl = self.seoUrlYolla
            getpostDetay.indexNoAl = self.indexYolla
            
        }
        else{
            print("error occured")
        }
        
    }
    
}
