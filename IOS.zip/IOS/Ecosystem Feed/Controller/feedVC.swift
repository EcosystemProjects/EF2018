//
//  feedVC.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 17.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit


struct EcoFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
   // let category:String
   // let ecosystem:String
   // let region:String
    let shareurl:String
    
}

class feedVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

   
    @IBOutlet weak var tableView: UITableView!
    
    let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]
    var dz = [String]()  // boş dizi
    var degerAl:String!
    var sayac:Int = 0 ,sayac2 = 0 ,sayac3 = 0
    //var degerAlata:String!
    var servisUzunluk:Int!
    var indexAl:Int = 0
    //http://ecosystemfeed.com/assets/img/posts/oludeniz.jpg
   // var nameArray = ["oludeniz","oludeniz2"]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let keyboardRecognizer = UITapGestureRecognizer(target: self, action:#selector(feedVC.hideKeyboard))
        
        self.view.addGestureRecognizer(keyboardRecognizer)
        tableView.delegate = self
        tableView.dataSource = self
     
        
        getAllPostVeriDondur()
    }
    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return imgArray.count
            //getServisLenght()
            //servisUzunluk
            //dz.count
             //imgArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as! feedCell
        
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")
        let urlSession = URLSession.shared
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             //print(response)
             
             }*/
        
            guard let data = data else {return}
            print("data", data)
            print("indexPath :", indexPath)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
                
                print("indexPath.row :", indexPath.row)
               
                    cell.userNameLabel.text! = json[indexPath.row].title
                    cell.LabelTexrAlani.text! = json[indexPath.row].description
                    cell.postImage.image = self.imgArray[indexPath.row]
                
                //a). cell.postImage.image = UIImage(named: "https://ecosystemfeed.com\(json[indexPath.row].image)")
                //b). cell.postImage.image = UIImage(named:"\(json[indexPath.row].image)")
                // a ve b kısım neden olmuyor onu araştırıyorum mantıklı olan bu alanların çalışmasıdır..
                
                if cell.postImage.image != nil{ // Şuanlık resim için kontrol yapıldı diğerleri
                                                //için de yapılıcak
                    print("json[indexPath.row].image :",json[indexPath.row].image)
                    
                }else{
                   
                    print("Resim almada hata")
                }
               print(" sıra \(indexPath.row)")
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
       
        //cell.postUudiLabel.isHidden = true
 
        return cell
 
    }
    
    
    @IBAction func leranMoreBtn(_ sender: Any) {
       
        performSegue(withIdentifier: "postDescriptionVeriAktarimi", sender: Any?.self)
         self.indexAl += 1
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let veriAktar = segue.destination as! PostViewDescription
        
        if self.indexAl == 1{
            print("self.indexAl ",self.indexAl," self.getVeriGetir() : ",self.getVeriGetir()," dz2.count :",dz2.count)
            
            veriAktar.gelenVeriyiAl = dz2[self.indexAl-1]
            //self.getVeriGetir()
        }
        
        if self.indexAl == 2{
            print("self.indexAl ",self.indexAl," self.getVeriGetir() : ",self.getVeriGetir(),"dz2.count :",dz2.count)
            
            veriAktar.gelenVeriyiAl = dz2[self.indexAl-1]
            //self.getVeriGetir()
        }
        
        
    }
    var dz2 = [String]()
    func veriAl(deger :String,uzunluk:Int,resim:String) {
        
        self.degerAl = deger //title değerini tutar
        self.servisUzunluk = uzunluk
        self.dz.append(resim)
        self.dz2.append(deger)
        print("self.sayac2 :",self.sayac2 , " - " + " dz.count :" ,dz.count ,"uzunluk :",uzunluk)
        
        while self.sayac2 < self.dz2.count {
            print("dz2 elemanları :\(dz2[self.sayac2])")
            self.sayac2 += 1
        }
       
        print("deger ",deger)
       
    }
    func getVeriGetir() -> String{ //web servisten title bilgisini çeker ona göre sorgu yapmak için
        
       return self.dz2[self.indexAl-1]
            //self.degerAl
    }
    func getServisLenght() -> Int{//web servisten servis uzunluğunu çeker ona göre döngüye sokmak için
        //servis uzunluğundan kasıt sunucuda toplam ne kadar bilgi barındırıyorum..
        return dz2.count
    }
    
    func getAllPostVeriDondur()  {
     
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")
        let urlSession = URLSession.shared
        
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             print(response)
             }
            */
            guard let data = data else {return}
            //print("data", data)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
              // self.degerAlAta = json[0].title
                while self.sayac < json.count{
                    self.veriAl(deger:json[self.sayac].title,uzunluk: json.count,resim:json[self.sayac].image)
                    
                    print("self.sayac :",self.sayac)
                    self.sayac += 1
                }
                
                
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
      
}
}
