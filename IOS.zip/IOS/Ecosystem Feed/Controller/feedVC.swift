//
//  feedVC.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 17.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit


struct EcoFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
   // let category:String
   // let ecosystem:String
   // let region:String
    let shareurl:String
    
}

class feedVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

   
    @IBOutlet weak var tableView: UITableView!
    
    let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]
   
    //http://ecosystemfeed.com/assets/img/posts/oludeniz.jpg
   // var nameArray = ["oludeniz","oludeniz2"]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let keyboardRecognizer = UITapGestureRecognizer(target: self, action:#selector(feedVC.hideKeyboard))
        
        self.view.addGestureRecognizer(keyboardRecognizer)
        tableView.delegate = self
        tableView.dataSource = self
       
    }
    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return imgArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as! feedCell
        
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")
        let urlSession = URLSession.shared
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             //print(response)
             
             }*/
        
            guard let data = data else {return}
            print("data", data)
            print("indexPath :", indexPath)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
           
                print("indexPath.row :", indexPath.row)
               
                    cell.userNameLabel.text! = json[indexPath.row].title
                    cell.LabelTexrAlani.text! = json[indexPath.row].description
                    cell.postImage.image = self.imgArray[indexPath.row]
                
                //a). cell.postImage.image = UIImage(named: "https://ecosystemfeed.com\(json[indexPath.row].image)")
                //b). cell.postImage.image = UIImage(named:"\(json[indexPath.row].image)")
                // a ve b kısım neden olmuyor onu araştırıyorum mantıklı olan bu alanların çalışmasıdır..
                
                if cell.postImage.image != nil{ // Şuanlık resim için kontrol yapıldı diğerleri
                                                //için de yapılıcak
                    print("json[indexPath.row].image :",json[indexPath.row].image)
                    
                }else{
                   
                    print("Resim almada hata")
                }
               print(" sıra \(indexPath.row)")
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
       
        //cell.postUudiLabel.isHidden = true
 
        return cell
 
    }
    
    
    
    
    
    
    func getAllPostLength() {
     
        let url = URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")
        let urlSession = URLSession.shared
        //let uzunluk:Int?
        
        urlSession.dataTask(with: (url)!) { (data, response, error) in
            /* if let response = response{
             print(response)
             }
            */
            guard let data = data else {return}
            //print("data", data)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
               
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
        
}
}
