//
//  feedVC.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 17.07.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

/*
struct EcoFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
   // let category:String
   // let ecosystem:String
   // let region:String
    let shareurl:String
    
}
*/
class feedVC: UIViewController, UITableViewDelegate, UITableViewDataSource ,PostsDataDelegate  {

   
    @IBOutlet weak var tableView: UITableView!
   
    let dataSource = AllPostsDataSource()
    var AllPostsArray : [EcoFeed] = []
   
    
   // let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]
    var dz = [String]()  // boş dizi
    var degerAl:String!
    var sayac:Int = 0 ,sayac2 = 0 ,sayac3 = 0
    //var degerAlata:String!
    var servisUzunluk:Int!
    var indexAl:Int = 0
   // var veriYolla :String = "getAllPosts"
    //http://ecosystemfeed.com/assets/img/posts/oludeniz.jpg
   // var nameArray = ["oludeniz","oludeniz2"]
    
    override func viewDidLoad() {
        
        let keyboardRecognizer = UITapGestureRecognizer(target: self, action:#selector(feedVC.hideKeyboard))
       self.dataSource.delegate = self
        self.view.addGestureRecognizer(keyboardRecognizer)
        tableView.delegate = self
        tableView.dataSource = self
     
        
        getAllPostVeriDondur()
        super.viewDidLoad()
    }
    
    func tumPostlar(getAllPostsList : [EcoFeed]) {
        self.AllPostsArray = getAllPostsList
       // print("self.AllPostsArray: ",self.AllPostsArray)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    
    }
    override func viewWillAppear(_ animated: Bool) {
       // print("self.veriYolla gelmiş mi",self.veriYolla ,"self.AllPostsArray: ",self.AllPostsArray)
        dataSource.loadAllPostsList()
        //veriAl:veriYolla
    }
    
    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if self.AllPostsArray.count > 0{
            
            return self.AllPostsArray.count
        }
        else{
            
            return 1
        }
       
        // return 3
            //imgArray.count
            //AllPostsArray.count
            //imgArray.count
            //getServisLenght()
            //servisUzunluk
            //dz.count
             //imgArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! feedCell
       
        
        //print("indexpath ->",indexPath.row)
       //print("geldi \(indexPath.row)")
       // print("self.AllPostsArray.count" ,AllPostsArray.count)
       
        if 0 < AllPostsArray.count{
          
            // let getirPostlari = self.AllPostsArray[indexPath.row % AllPostsArray.count]
            
               
                cell.userNameLabel.text = self.AllPostsArray[indexPath.row ].title
                cell.postImage.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+self.AllPostsArray[0].image))!))
                cell.LabelTexrAlani.text = self.AllPostsArray[indexPath.row ].description
            
            if (cell.userNameLabel.text != "" ) && (cell.postImage.image != nil) && (cell.LabelTexrAlani.text != ""){
            }else{
                print("Veriler Tam Yüklenmeli..Biraz Bekleyiniz .Olmadıysa  ",
                    "INTERNETİNİZ YAVAŞ OLABİLİR")
            }
           
            
        }
        else{
            print("")
        }
        
        return cell
 
    }
    
    
    var dz2 = [String]()
    @IBAction func leranMoreBtn(_ sender: Any) {
          self.indexAl += 1
        performSegue(withIdentifier: "postDetay", sender: Any?.self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is PostViewDescription){
            let getpostDetay = segue.destination as! PostViewDescription
            getpostDetay.gelenVeriyiAl = dz2[self.indexAl-1]
        }
    }
   
    func veriAl(deger :String,uzunluk:Int,resim:String) {
        
        self.degerAl = deger //title değerini tutar
        self.servisUzunluk = uzunluk
        self.dz.append(resim)
        self.dz2.append(deger)
        print("self.sayac2 :",self.sayac2 , " - " + " dz.count :" ,dz.count ,"uzunluk :",uzunluk)
        
        while self.sayac2 < self.dz2.count {
            print("dz2 elemanları :\(dz2[self.sayac2])")
            self.sayac2 += 1
        }
       
        print("deger ",deger)
       
    }
    func getVeriGetir() -> String{ //web servisten title bilgisini çeker ona göre sorgu yapmak için
        
       return self.dz2[self.indexAl-1]
            //self.degerAl
    }
    func getServisLenght() -> Int{//web servisten servis uzunluğunu çeker ona göre döngüye sokmak için
        //servis uzunluğundan kasıt sunucuda toplam ne kadar bilgi barındırıyorum..
        return dz2.count
    }
    
    func getAllPostVeriDondur()  {
     
        var request = URLRequest(url: URL(string: "https://ecosystemfeed.com/Service/Web.php?process=getAllPosts")!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        let urlSession = URLSession.shared
        
        urlSession.dataTask(with: request) { (data, response, error) in

            /* if let response = response{
             print(response)
             }
            */
            guard let data = data else {return}
            //print("data", data)
            do{
                let json = try JSONDecoder().decode([EcoFeed].self,from: data)
              // self.degerAlAta = json[0].title
                while self.sayac < json.count{
                    self.veriAl(deger:json[self.sayac].title,uzunluk: json.count,resim:json[self.sayac].image)
                    
                    print("self.sayac :",self.sayac)
                    self.sayac += 1
                }
                
                
                
            }catch{
                print(   "HATA :" ,error)
            }
            }.resume();
      
}
}
