//
//  ViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 18.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import OneSignal

class ViewController: UIViewController {
    
    @IBOutlet weak var byMentornity: UILabel!
    @IBOutlet weak var ecosystemFeed: UILabel!
    @IBOutlet weak var followCategories: UILabel!
    @IBOutlet weak var connectVia: UIButton!
    @IBOutlet weak var browseEco: UIButton!
    @IBOutlet weak var termsOf: UIButton!
    var user = UserDataSource()
    var authID:String = ""
    var  userID:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        connectVia.layer.cornerRadius = 10
        browseEco.layer.borderWidth = 1
        browseEco.layer.cornerRadius = 10
       
        
        let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
        
         userID = status.subscriptionStatus.userId
        print("userID = \(userID)")
   
    }

   
    @IBAction func connecVia(_ sender: Any) {
        
        self.authID = "hjdskfm"
        print("GELDİİ...self.authID2 :>",self.authID )
        
        
        let permission : [AnyObject] = [LISDK_BASIC_PROFILE_PERMISSION as AnyObject,LISDK_EMAILADDRESS_PERMISSION as AnyObject]
        
        LISDKSessionManager.createSession(withAuth: permission, state: nil, showGoToAppStoreDialog: true, successBlock: { (success) in
 
            
            let url = "https://api.linkedin.com/v1/people/~"
            
            if(LISDKSessionManager.hasValidSession()){
                
                LISDKAPIHelper.sharedInstance().getRequest(url, success: { (response) in
                  
                    print(response ?? LISDKErrorCode.self)
                    
                    if response?.statusCode == 200 {
                        print("sucsess",response!)
                        
                    }
                    else{
                        print("status code 200 deil")
                    }
                  /*  let dict = self.stringToDictionary(text: (response?.data)!)
                    print("your last name is \(String(describing: dict?["lastname"]))")
                    UserDefaults.standard.set(true, forKey: "user")
                    UserDefaults.standard.synchronize()
                    let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
                    delegate.rememberLogin()
                     
                     */
                    
                    
                    
                    
            /*
            if let response = response {
                let data = response.data.data(using: .utf8)
                let dictResponse = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSDictionary
               
                let firstName = dictResponse.value(forKey: "fistname")
                let authid = dictResponse.value(forKey: "id")
                let emailAddress = dictResponse.value(forKey: "emailAddress")
                let lastName = dictResponse.value(forKey: "lastName")
                let publicProfileUrl = dictResponse.value(forKey: "publicProfileUrl") // daha farklı olaınıyordu bakarsın ona
                
                
                DispatchQueue.main.async {
                     
                    //Burdan verileri alacam ,Linkedin Bilgilerini veya üstten
                    
                   // self.user.userBilgileri(authId: authid as! String, firstName: firstName as! String, lastName: lastName as! String, emailAddress: emailAddress as! String, publicProfileUrl: publicProfileUrl as! String) // Burdan api ye ilgili verileri verip çıktı alacamm insaAllah
                    
                    
                    //self.name.text = name as? String
                    //self.img.image = UIImage.init(data Data.init(contentsOf:URl(string:umgurl as? String)!)!)
                }
                
            }
            */
            
            
                    
                }, error: { (error) in
                    print("error :",error ?? LISDKAPIError?.self)
                    
                })
  
            }else{print("session failed !!!!")}
        }) { (error) in
            print("Error\(error!)")
        }
        
        performSegue(withIdentifier: "getStarted", sender: nil)
       
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let getStart = segue.destination as! welcomeViewController
        getStart.authID = self.authID
        getStart.userID = self.userID
    }
    
    
    
    
    func stringToDictionary(text: String)-> [String: Any]?{
        if let data = text.data(using: .utf8){
            do{
                return (try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any])!
            }catch{
                print("error.localizedDescription :",error.localizedDescription)
            }
        }
        return nil
    }
    
    
    
}

