//
//  CategoryFollowMeViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 27.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//
import UIKit
import Foundation
class CategoryFollowMeViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource,getCategorisFollowMeDelegete{

    @IBOutlet weak var tableView: UITableView!
    
    var folloWCategoryMedataSource = getCategorisFollowMeDataSource()
    var authID :String = ""
   
    var categoryfollowMeDz1 :[Any] = []
    @IBOutlet var mScrollView:UIScrollView!
    override func viewDidLoad() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
     
        folloWCategoryMedataSource.delegate=self
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        print("CategoryFollowMeViewController da authID :> ",authID)
        folloWCategoryMedataSource.followMeCategory(authID: self.authID)
    
    }
   
    func getCategoryFollowMe2(getCategoryFMe: [Any]) {
        self.categoryfollowMeDz1 = getCategoryFMe
       
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
      
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if categoryfollowMeDz1.count != 0 {
            return categoryfollowMeDz1.count
        }else{
            return 0
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "categoryfollowName", for: indexPath) as! CategoryFollowMeCell
        print("Bu alana geldi.. \(categoryfollowMeDz1[indexPath.row] as? String)")
        if categoryfollowMeDz1.count > 0 {
        
            cell.categoryFName.setTitle((categoryfollowMeDz1[indexPath.row] as? String)!, for: .normal)
            
        }else{
            alertMesaj()
        }
        
        return cell
        
    }
    func alertMesaj(){
        let alert = UIAlertController(title: "Category Durum", message: "Category Bulunmamaktadır..", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "TAMAM", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
}
