//
//  CategoryFollowMeViewController.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 27.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//
import UIKit
import Foundation
class CategoryFollowMeViewController: UIViewController ,getCategorisFollowMeDelegete{
    
    var folloWCategoryMedataSource = getCategorisFollowMeDataSource()
    var authID :String = ""
    var categoryfollowMeDz :[CategoryFollowMe] = []
    @IBOutlet var mScrollView:UIScrollView!
    override func viewDidLoad() {
    
        folloWCategoryMedataSource.delegate=self
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        print("authID , ne geldi :> ",authID)
        folloWCategoryMedataSource.followMeCategory(authID: self.authID)
    
    }
    func getCategoryFollowMe(getCategoryFMe: [CategoryFollowMe]) {
        self.categoryfollowMeDz = getCategoryFMe
        setButtons()
    }
    
    func setButtons(){
        DispatchQueue.main.async {
            let numberOfButtons = self.categoryfollowMeDz.count
            let px = self.self.mScrollView.center.x
            var py = 90
            
            if(self.categoryfollowMeDz.count == 0){
                return
            }
            
            for count in 0...numberOfButtons-1 {
                
                let button = UIButton()
                button.tag = count
                button.frame = CGRect(x: Int(px)-(Int(self.mScrollView.contentSize.width-10)/2), y:py, width: Int(self.mScrollView.contentSize.width-10), height: 45)
                button.backgroundColor = UIColor.lightGray
                button.setTitle("\(self.self.categoryfollowMeDz[count])", for: .normal)
                                    // api verilerini çekmedik henüz
                
                button.layer.cornerRadius = 9
                
               // button.addTarget(self, action: #selector(self.scrollButtonAction), for: .touchUpInside)
                
                self.mScrollView.addSubview(button)
                py += 50
            }
        }
    }
    
}
