//
//  thirdViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 19.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class thirdViewController: UIViewController {

    var authID:String = ""
    var profil:String = ""
    var mailGonder:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
       

    }
    override func viewWillAppear(_ animated: Bool) {
        if CheckInternet.Connection(){
            
            //alertMesaj(title: "Internet Connection ", mesaj: "İnternet Connection")
            
            let tabbar = tabBarController as! CustomTabBar
            self.authID = tabbar.authID
            self.profil = tabbar.profilGonder
            self.mailGonder = tabbar.mailAdres
            print("thirdViewController da self.authID :>",self.authID)
        }
        else{
            alertMesaj(title: "Internet Connection ", mesaj: "İnternetiniz yok, veya internete bağli değilsiniz.. .İşlem yapabilmek için internete bağlanmalısınız..")
        }
        
        
    }
    //alert mesaj
    func alertMesaj(title:String,mesaj:String){
        let alert = UIAlertController(title: title, message: mesaj, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Tamam", style: UIAlertActionStyle.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func mansurEminKaya(_ sender: Any) {
        if let url = NSURL(string: "https://www.linkedin.com/feed/"){
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
        }//https://www.facebook.com/mentornity/?ref=br_rs
    }
    
    @IBAction func contactBtn(_ sender: Any) {
        performSegue(withIdentifier: "baglantilar", sender: nil)
    }
    @IBAction func about(_ sender: UIButton) {
        performSegue(withIdentifier: "hakkinda", sender: nil)
    }
    @IBAction func settingsButton(_ sender: Any) {
        performSegue(withIdentifier: "setting", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is settingsViewController){
            let settings = segue.destination as! settingsViewController
              settings.profilAl = self.profil
              settings.authID = self.authID
              settings.mailAl = self.mailGonder
              
        }
        else if (segue.destination is contactViewController) {
            
        }else if (segue.destination is contaViewController) {
            
        }
        
    }
    
}
