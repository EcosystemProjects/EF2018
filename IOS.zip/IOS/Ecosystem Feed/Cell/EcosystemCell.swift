//
//  EcosystemCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 24.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class EcosystemCell :UITableViewCell{
    @IBOutlet var ecosystemName:UIButton!
}
