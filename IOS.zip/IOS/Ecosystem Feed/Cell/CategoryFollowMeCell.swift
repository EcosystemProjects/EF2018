//
//  CategoryFollowMeCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 16.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class CategoryFollowMeCell :UITableViewCell {
    
    @IBOutlet var categoryFName:UIButton!
}
