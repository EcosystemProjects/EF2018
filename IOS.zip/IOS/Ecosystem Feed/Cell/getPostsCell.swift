//
//  getPostsCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 3.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class getPostsCell :UITableViewCell{
    @IBOutlet var lblTitle:UILabel!
    @IBOutlet var imgResim:UIImageView!
    @IBOutlet weak var tarih: UILabel!
    
    @IBOutlet weak var txtview: UITextView!
    /*
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
 */
}
