//
//  MyPostsCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 27.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class MyPostsCell: UITableViewCell {
    
    @IBOutlet var categoryInformation:UILabel!
    @IBOutlet var img:UIImageView!
    @IBOutlet var date:UILabel!    
    @IBOutlet var desc: UITextView!
    
}
