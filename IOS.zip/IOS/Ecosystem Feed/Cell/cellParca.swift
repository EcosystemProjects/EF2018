//
//  cellParca.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

class cellParca: UICollectionViewCell {
    
    //@IBOutlet weak var imgImage: UIImageView!
    //@IBOutlet weak var  lbl: UILabel!
    //@IBOutlet weak var descriptionAlani: UITextView!
    
   
    @IBOutlet weak var descriptionAlani: UILabel!
    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var lbl: UILabel!
    
    
    
}
