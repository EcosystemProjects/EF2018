//
//  AllCategory.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class AllCategory:UITableViewCell{
    
    @IBOutlet var categoryName:UILabel!
    @IBOutlet var postsBtn:UIButton!
     @IBOutlet var takipcilerBtn:UIButton!
     @IBOutlet var followYapBtn:UIButton!
    

}
