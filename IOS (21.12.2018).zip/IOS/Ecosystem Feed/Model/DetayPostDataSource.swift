//
//  DetayPostDataSource.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 16.11.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
protocol DetayPostDelegate {
    func detayPostListLoaded(PostDetayList : [EcosystemPostDecsription])
}

extension DetayPostDelegate{
    func detayPostListLoaded(PostDetayList : [EcosystemPostDecsription]) { }
}


class DetayPostDataSource : NSObject {
    
    var delegate : DetayPostDelegate?
    
    func detayPostList(detayPostName : String)
    {
        if detayPostName == ""{
            print(" detayPostName değeri boş ")
            
        }
        else{
        
            let sorguUrl = "https://ecosystemfeed.com/Service/Web.php?process=getPosts&seourl=\(detayPostName)"
         let txtSorguUrl = sorguUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            var request = URLRequest(url: URL(string: txtSorguUrl!)!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, response, error) in
        let decoder = JSONDecoder()
            do {
                let detayArray = try decoder.decode([EcosystemPostDecsription].self, from: data!)
                
                 // print("detayArray :>",detayArray)
                self.delegate?.detayPostListLoaded(PostDetayList: detayArray)
              
            }
            catch{
                self.delegate?.detayPostListLoaded(PostDetayList: [])
                print("no categories")
            }
        }
        
        dataTask.resume()
          
        }
    }
    
}
