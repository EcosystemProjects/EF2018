//
//  welcomeViewController.swift
//  Ecosystem Feed
//
//  Created by Ahmet Buğra Peşman on 20.06.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
import Foundation
import  Alamofire
/*
struct LinkedinUser :Codable {
    
    let json:Nesne
}
struct Nesne :Codable {
    let authId:String
    let firstName:String
    let lastName:String
    let emailAddress:String
    let publicProfileUrl:String
    
    init(authId: String, firstName: String, lastName: String,emailAddress: String,publicProfileUrl: String) {
        self.authId = authId
        self.firstName = firstName
        self.lastName = lastName
        self.emailAddress = emailAddress
        self.publicProfileUrl = publicProfileUrl
    }
}
 */
class welcomeViewController:  UIViewController ,UserDataDelegate{
    var getAuthId: String = ""
    

   
    @IBOutlet weak var getStarted: UIButton!
    
    var user = UserDataSource()
    var notiBildirim = NotificationDataSource()
    var authID:String = ""
    var userID:String = ""
    var firstName:String = ""
    var lastName:String = ""
    var emailAddress:String = ""
    var publicProfileUrl:String  = ""
    
    override func viewDidLoad() {
        
       user.delegate = self
        getStarted.layer.cornerRadius = 10
      
        //self.notiBildirim.notificaitonList(authID: self.authID, userID: self.userID) //notification kayıt seervisi burdan yapılıcak
       
        super.viewDidLoad()

    }


    override func viewWillAppear(_ animated: Bool) {
        print("welcomeViewController dayız :)")
   
        self.user.userBilgileri(authId: "S7UA261fjN" , firstName: "mansur emin" , lastName: "kaya" , emailAddress: "kayamansur61@gmail.com" , publicProfileUrl: "https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM")
        
     //bu kısıma veriler viewControllerdan geliyor..
 //print("authID  :>",self.authID ,"-","userID :>",self.userID,"-","fisrtName :>",self.fisrtName,"-","lastName :>",self.lastName,"-","emailAddress :>",self.emailAddress,"-","publicProfileUrl :>",self.publicProfileUrl)
        
    }
    
    func getUserMesaj(mesaj: String, sessionID: String) {
        if (mesaj == "success login" ) || (sessionID != "") {
            print("mesaj :>",mesaj)
            print("sessionID :>",sessionID)
        }
        else{
            print("Böyle bir kullanıcı yok ")
        }
    }
 
    
    @IBAction func logOut(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "user")
        UserDefaults.standard.synchronize()
        
        let SignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUp") as? ViewController
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = SignUp
        delegate.rememberLogin()
    }
   
    @IBAction func getStart(_ sender: Any) {
        
       performSegue(withIdentifier: "basla", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.destination is CustomTabBar){
            let custumBar = segue.destination as! CustomTabBar
            custumBar.authID = "S7UA261fjN"
        }
        else{
            print("error occured")
        }
        
    }
    
    
    
}
