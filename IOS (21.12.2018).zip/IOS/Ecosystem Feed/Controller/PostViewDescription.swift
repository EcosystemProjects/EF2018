//
//  PostViewDescription.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 23.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit

// NOT : BU POSTDESCRİPTİON VIEW KISMINI KALDIRACAM

class PostViewDescription: UIViewController ,DetayPostDelegate {
    
    let imgArray = [UIImage(named: "oludeniz")/*,UIImage(named: "oludeniz")*/]
    let dataSource = DetayPostDataSource()
    var postDetayArray :[EcosystemPostDecsription] = []
 
    @IBOutlet weak var lblGelenVeri: UILabel!
    
    @IBOutlet weak var img2: UIImageView!
    var gelenVeriyiAl:String = ""
    var seoUrlAl:String = ""
    @IBOutlet weak var descriptionAlani: UITextView!
    @IBOutlet weak var regionGetir: UILabel!
    
    @IBOutlet weak var ecosystemGetir: UILabel!
    
    @IBOutlet weak var categoryGetir: UILabel!
    
    @IBOutlet weak var tarih: UILabel!
    
    
    var indexNoAl:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource.delegate =  self
        // Do any additional setup after loading the view.
        
        if (gelenVeriyiAl == ""){
            print("Herhangi bir değer yok")
        }else{
            lblGelenVeri.text = gelenVeriyiAl
            print("gelenVeriyiAl :>",gelenVeriyiAl)
            print("indexNoAl :>",indexNoAl)
             print("seoUrlAl :>",seoUrlAl)
            print("lblGelenVeri.text ",lblGelenVeri.text!)
        }
       // getAllPost()
       
        
    }
    func detayPostListLoaded(PostDetayList: [EcosystemPostDecsription]) {
        self.postDetayArray = PostDetayList
        print("self.postDetayArray.count :>",self.postDetayArray.count)
        DispatchQueue.main.async {
            self.verileriGoster()
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        dataSource.detayPostList(detayPostName: self.seoUrlAl)
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    func verileriGoster(){
        
        self.regionGetir.text! = postDetayArray[self.indexNoAl].region
        self.img2.image = self.imgArray[0]
        self.ecosystemGetir.text! = postDetayArray[self.indexNoAl].ecosystem
        self.categoryGetir.text! = postDetayArray[self.indexNoAl].category
        self.tarih.text! = postDetayArray[self.indexNoAl].date
        self.descriptionAlani.text! = postDetayArray[self.indexNoAl].description
        self.img2.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+postDetayArray[self.indexNoAl].image))!))
          
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
