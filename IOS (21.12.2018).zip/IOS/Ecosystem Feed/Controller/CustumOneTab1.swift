//
//  CustumOneTab1.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 19.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class CustumOneTab1:UITabBarController{
    
    var authID:String = ""
    var tabbarItem = UITabBarItem()
    
    override func viewDidLoad() {
        
        print("authID , CustomTabBar da:>:>:>",authID)
        super.viewDidLoad()
    }
}
