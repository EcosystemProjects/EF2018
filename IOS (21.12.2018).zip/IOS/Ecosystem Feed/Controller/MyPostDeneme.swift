//
//  Deneme.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 13.10.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import UIKit
/*
struct EcosystemFeed:Decodable {
    let title:String
    let description:String
    let image:String
    let date:String
    let category:String
    let ecosystem:String
    let region:String
    let shareurl:String
    
}
 */
class MyPostDeneme: UIViewController , UICollectionViewDelegate,UICollectionViewDataSource,MyPostDataDelegate,UserDataDelegate{
   var getAuthId: String = ""
    let imgArray = [UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz"),UIImage(named: "oludeniz")]

    @IBOutlet weak var cellectionView: UICollectionView!
    var dataSource = MyPostDataSource()
    var user = UserDataSource()
    let welcomeControl = welcomeViewController()
    var deleteSource = DeletePostDataSoUrce()
    var myPostsArray:[myPosts] = []
    var categoryAdi:String = ""
    var authIDGetir:String = ""
    var seoURLGetir:String = ""
    var categoryDizi:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSource.delegate=self
        user.delegate = self
        
        
       
        // Do any additional setup after loading the view.
    }
    func myPostsListLoaded(mPostsList: [myPosts]) {
        self.myPostsArray=mPostsList
        DispatchQueue.main.async {
            self.cellectionView.reloadData()
        }
        
    }
    func getUserMesaj(mesaj: String, sessionID: String) {
        print("My posts Denemeden selamlar :> \(mesaj) , \(sessionID)")
    }
    
    override func viewWillAppear(_ animated: Bool) {
       // print("user.getSessionIdGetir() :",user.getSessionIdGetir()) OLMADI
        // user.userInformation() OLMADI
         self.user.userBilgileri(authId: "S7UA261fjN" , firstName: "mansur emin" , lastName: "kaya" , emailAddress: "kayamansur61@gmail.com" , publicProfileUrl: "https://www.linkedin.com/profile/view?id=AAoAACJdYnkB9mW2ZMCIQ_Fq3kUcKEat0afi09wM")
        if (authIDGetir != "") {            
            print("authIDGetir :>",authIDGetir )
        }else{
           
            print(" Boş authID")
        }
        
       // print("authIDGetir :>",authIDGetir )
       
        dataSource.myPostsList(authID: authIDGetir)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //web servisten dönen uzunluk dönmeli
        return myPostsArray.count
            //imgArray.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "cellParca1", for: indexPath) as!  cellParca
     
        
        if myPostsArray.count > 0{
           let categoryAd = self.myPostsArray[indexPath.row % myPostsArray.count]
            
            cell.lbl.text! = myPostsArray[indexPath.row].region + "-"+myPostsArray[indexPath.row].ecosystem+"-"+myPostsArray[indexPath.row].category+"\n"+myPostsArray[indexPath.row].title
            cell.descriptionAlani.text! = myPostsArray[indexPath.row].date
           cell.aciklamaAlani.text! = myPostsArray[indexPath.row].description //hata oluvcak mı..           
            cell.imgImage.image = self.imgArray[indexPath.row]
           
            categoryDizi.append(categoryAd.seourl)
             //print("categoryDizi[indexPath.row] :>",categoryDizi[indexPath.row])
            //   cell.imgImage.image = self.imgArray[indexPath.row]
           // cell.imgImage.image = UIImage.init(data: try! Data.init(contentsOf: URL(string: ("http://ecosystemfeed.com"+myPostsArray[0].image))!)) // 1. indexte sunucudan hata alınıyor beratın düzeltmesi lazım Resim doğru formatta değil
            
            
            return cell
        }
        else{
            cell.lbl.text! = " " //Sunucu yavaş çalışıyor olabilir.
            return cell
        }
        
        
        
    }
    var sayac:Int = 0
    @IBAction func deletePosstMe(_ sender: Any) {
        print("self.categoryDizi[\(self.sayac)] :>" ,self.categoryDizi[self.sayac])
        deleteSource.deletePost(authID: self.authIDGetir, seoUrl: self.categoryDizi[self.sayac])
                                                        //self.seoURLGetir
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
