//
//  FollowCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 3.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation
class FollowCell :UITableViewCell{
    
    @IBOutlet var followPersons:UILabel!
    
}
