//
//  FollowersCell.swift
//  Ecosystem Feed
//
//  Created by Mansur Emin Kaya on 15.12.2018.
//  Copyright © 2018 Ahmet Buğra Peşman. All rights reserved.
//

import Foundation

class  FollowersCell: UITableViewCell {
    @IBOutlet var followName:UIButton!
}
